MongoDB database setup

1. Install and start MongoDB locally, or create a MongoDB Atlas database.
2. Put the connection string in backend/.env as MONGO_URI.
3. Start the backend.
4. Optional: run `node seed.js` from backend after `npm install` to create demo users.

Demo login:
Doctor: doctor@example.com / Password123
Patient: patient@example.com / Password123
