import React, { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, Legend } from 'recharts';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { useLanguage } from '../i18n';
import EmergencySOS from './EmergencySOS';

export default function Dashboard() {
  const { t } = useLanguage();
  const [summary, setSummary] = useState(null);
  const [records, setRecords] = useState([]);
  const [doctorStats, setDoctorStats] = useState(null);
  const [adminStats, setAdminStats] = useState(null);
  const [insights, setInsights] = useState(null);
  const role = localStorage.getItem('role');
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    if (role === 'patient') {
      api.get('/health/summary').then(r => setSummary(r.data)).catch(() => {});
      api.get('/health').then(r => setRecords(r.data)).catch(() => {});
      api.get('/insights').then(r => setInsights(r.data)).catch(() => {});
    }
    if (role === 'doctor') {
      api.get('/dashboard/stats').then(r => setDoctorStats(r.data)).catch(() => {});
    }
    if (role === 'admin') {
      api.get('/admin/overview').then(r => setAdminStats(r.data)).catch(() => {});
    }
  }, [role]);

  const chartData = records.slice(0, 10).reverse().map(x => ({
    date: new Date(x.recordedAt).toLocaleDateString(),
    heartRate: x.heartRate,
    spo2: x.spo2
  }));

  return (
    <>
      <header className="topbar"><div><h1>{t('goodDay')}, {user.name || 'User'} 👋</h1>
        <p className="muted">{t('monitorOne')}</p></div></header>

      {role === 'patient' && (
        <>
          <section className="grid stats">
            <div className="card"><span>{t('heartRate')}</span><strong>{summary?.heartRate ?? '--'} BPM</strong></div>
            <div className="card"><span>{t('bloodPressure')}</span><strong>{summary?.bloodPressure ?? '--'}</strong></div>
            <div className="card"><span>{t('oxygen')}</span><strong>{summary?.spo2 ?? '--'}%</strong></div>
            <div className="card"><span>{t('temperature')}</span><strong>{summary?.temperature ?? '--'}°F</strong></div>
          </section>
          {insights && (
            <div className="card ai-summary">
              <div>
                <span className="eyebrow">AI-assisted trend check</span>
                <h2>{insights.wellnessScore ?? '--'}<small>/100</small> monitoring score</h2>
                <p>{insights.summary}</p>
                {insights.insights?.[0] && <p><strong>{insights.insights[0].title}:</strong> {insights.insights[0].detail}</p>}
              </div>
              <Link className="primary btn-link" to="/insights">{t('viewInsights')}</Link>
            </div>
          )}
          <EmergencySOS />
          <div className="card chart-card">
            <h2>{t('recentTrend')}</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="heartRate" name="Heart Rate" stroke="#2563eb" />
                <Line type="monotone" dataKey="spo2" name="SpO2" stroke="#16733a" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </>
      )}

      {role === 'doctor' && doctorStats && (
        <>
          <section className="grid stats">
            <div className="card"><span>{t('totalPatients')}</span><strong>{doctorStats.patients}</strong></div>
            <div className="card"><span>{t('yourAppointments')}</span><strong>{doctorStats.appointments}</strong></div>
            <div className="card"><span>{t('activeAlerts')}</span><strong>{doctorStats.alerts}</strong></div>
          </section>
          <div className="card">
            <h2>Doctor Monitoring</h2>
            <p>Use <Link to="/patients">My Patients</Link> to review assigned patient records and health trends, or <Link to="/appointments">Appointments</Link> to manage bookings.</p>
          </div>
        </>
      )}

      {role === 'admin' && adminStats && (
        <>
          <section className="grid stats">
            <div className="card"><span>Patients</span><strong>{adminStats.patients}</strong></div>
            <div className="card"><span>Doctors</span><strong>{adminStats.doctors}</strong></div>
            <div className="card"><span>Total Appointments</span><strong>{adminStats.appointments}</strong></div>
            <div className="card"><span>Active Alerts</span><strong>{adminStats.alerts}</strong></div>
          </section>
          <div className="card">
            <h2>System Administration</h2>
            <p>Go to the <Link to="/admin">Admin Panel</Link> to manage user accounts and roles.</p>
          </div>
        </>
      )}
    </>
  );
}
