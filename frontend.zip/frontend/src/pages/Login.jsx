import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { LanguageSelector, useLanguage } from '../i18n';
import VoiceAssistant from '../components/VoiceAssistant';

export default function Login({ onLoginSuccess }) {
  const { t } = useLanguage();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'patient', specialization: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  React.useEffect(() => {
    const onVoiceFill = (event) => {
      const v = event.detail || {};
      setForm(prev => ({
        ...prev,
        ...Object.fromEntries(Object.keys(prev).filter(k => v[k] !== undefined).map(k => [k, v[k]]))
      }));
    };
    window.addEventListener('caretrack:voice-fill', onVoiceFill);
    return () => window.removeEventListener('caretrack:voice-fill', onVoiceFill);
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const url = mode === 'login' ? '/auth/login' : '/auth/register';
      const { data } = await api.post(url, form);
      localStorage.setItem('token', data.token);
      localStorage.setItem('role', data.user.role);
      localStorage.setItem('user', JSON.stringify(data.user));
      window.dispatchEvent(new Event('caretrack:auth-change'));
      if (onLoginSuccess) onLoginSuccess();
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Authentication error. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-language"><LanguageSelector /></div>
      <form className="card login-card" onSubmit={submit}>
        <h1>❤ CareTrack</h1>
        <p className="muted">{t('subtitle')}</p>

        {mode === 'register' && (
          <input
            placeholder={t('name')}
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
            required
          />
        )}

        <input
          type="email"
          placeholder={t('email')}
          value={form.email}
          onChange={e => setForm({ ...form, email: e.target.value })}
          required
        />

        <input
          type="password"
          placeholder={`${t('password')} (min 6 characters)`}
          value={form.password}
          onChange={e => setForm({ ...form, password: e.target.value })}
          required
          minLength={6}
        />

        {mode === 'register' && (
          <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
            <option value="patient">{t('patient')}</option>
            <option value="doctor">{t('doctor')}</option>
          </select>
        )}

        {mode === 'register' && form.role === 'doctor' && (
          <input
            placeholder={t('specialization')}
            value={form.specialization}
            onChange={e => setForm({ ...form, specialization: e.target.value })}
          />
        )}

        {error && <div className="error" style={{ marginBottom: 12, padding: 8, background: '#fee2e2', borderRadius: 6 }}>{error}</div>}

        <button className="primary" type="submit" disabled={loading} style={{ width: '100%', marginBottom: 12 }}>
          {loading ? 'Please wait…' : mode === 'login' ? t('login') : t('createAccount')}
        </button>

        <button
          type="button"
          className="link-btn"
          style={{ width: '100%', textAlign: 'center' }}
          onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }}
        >
          {mode === 'login' ? t('createNew') : t('haveAccount')}
        </button>
      </form>
      <VoiceAssistant />
    </div>
  );
}
