import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../services/api';
import { useLanguage } from '../i18n';

const API_ORIGIN = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/api\/?$/, '');

export default function Documents() {
  const { t } = useLanguage();
  const [items, setItems] = useState([]);
  const [title, setTitle] = useState('');
  const [file, setFile] = useState(null);
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);
  const role = localStorage.getItem('role');
  const [searchParams] = useSearchParams();
  const patientId = searchParams.get('patient');

  const load = () => api.get('/documents', { params: patientId ? { patientId } : {} }).then(r => setItems(r.data)).catch(() => {});
  useEffect(() => { load(); }, [patientId]);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (!file) { setError('Please choose a file'); return; }
    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', title || file.name);
    setUploading(true);
    try {
      await api.post('/documents', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      setTitle(''); setFile(null);
      document.getElementById('doc-file-input').value = '';
      load();
    } catch (err) { setError(err.response?.data?.message || 'Upload failed'); }
    finally { setUploading(false); }
  };

  const remove = async (id) => {
    if (!confirm('Delete this document?')) return;
    await api.delete(`/documents/${id}`);
    load();
  };

  return (
    <div>
      <h1>{t('medicalDocuments')}</h1>
      {role === 'patient' && (
        <div className="card">
          <h2>{t('uploadDocument')}</h2>
          <form className="form-grid" onSubmit={submit}>
            <input name="title" placeholder={t('titleOptional')} value={title} onChange={e => setTitle(e.target.value)} />
            <input id="doc-file-input" type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.doc,.docx"
              onChange={e => setFile(e.target.files[0])} />
            <button className="primary" type="submit" disabled={uploading}>{uploading ? 'Uploading…' : 'Upload'}</button>
          </form>
          {error && <p className="error">{error}</p>}
          <p className="muted">Accepted: PDF, images, Word docs. Max 10MB.</p>
        </div>
      )}
      <div className="card">
        <h2>{role === 'patient' ? 'Your Documents' : 'Patient Documents'}</h2>
        {role !== 'patient' && !patientId && <p className="muted">Open a patient from "My Patients" to view their documents.</p>}
        <div className="table-wrap">
          <table>
            <thead><tr>{role !== 'patient' && <th>Patient</th>}<th>Title</th><th>Type</th><th>Uploaded</th><th></th></tr></thead>
            <tbody>
              {items.map(d => (
                <tr key={d._id}>
                  {role !== 'patient' && <td>{d.patient?.name}</td>}
                  <td>{d.title}</td>
                  <td>{d.fileType}</td>
                  <td>{new Date(d.createdAt).toLocaleDateString()}</td>
                  <td className="row-actions">
                    <a className="secondary btn-link" href={`${API_ORIGIN}${d.fileUrl}`} target="_blank" rel="noreferrer">View</a>
                    {role === 'patient' && <button className="danger" onClick={() => remove(d._id)}>Delete</button>}
                  </td>
                </tr>
              ))}
              {items.length === 0 && <tr><td colSpan={5} className="muted">{t('noDocuments')}</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
