import React, { useEffect, useRef, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, Legend } from 'recharts';
import api from '../services/api';
import { useLanguage } from '../i18n';
import { parseForm } from '../components/VoiceAssistant';

const emptyForm = { heartRate: '', systolic: '', diastolic: '', spo2: '', temperature: '', bloodSugar: '', weight: '' };

export default function Health() {
  const { t, language } = useLanguage();
  const [form, setForm] = useState(emptyForm);
  const [records, setRecords] = useState([]);
  const [message, setMessage] = useState('');
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef(null);

  const load = () => api.get('/health').then(r => setRecords(r.data)).catch(() => {});
  useEffect(() => {
    load();
    const onVoiceFill = (event) => { const v=event.detail||{}; setForm(prev => ({...prev, ...Object.fromEntries(Object.keys(prev).filter(k=>v[k]!==undefined).map(k=>[k,v[k]]))})); };
    window.addEventListener('caretrack:voice-fill', onVoiceFill);
    return () => window.removeEventListener('caretrack:voice-fill', onVoiceFill);
  }, []);

  const update = (key, value) => setForm(prev => ({ ...prev, [key]: value }));

  const startVoice = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { setMessage(t('voiceUnsupported')); return; }
    if (listening) { recognitionRef.current?.stop(); return; }
    const recognition = new SpeechRecognition();
    recognition.lang = language;
    recognition.interimResults = true;
    recognition.continuous = false;
    recognition.onstart = () => setListening(true);
    recognition.onend = () => setListening(false);
    recognition.onerror = () => { setListening(false); setMessage(t('noCommand')); };
    recognition.onresult = (event) => {
      const text = [...event.results].map(x => x[0].transcript).join(' ');
      if (!event.results[event.results.length - 1].isFinal) return;
      const parsed = parseForm(text);
      const next = { ...form };
      Object.entries(parsed).forEach(([key, value]) => { if (key in next) next[key] = value; });
      setForm(next);
      setMessage(`${t('filled')} Voice: “${text}”`);
    };
    recognitionRef.current = recognition;
    recognition.start();
  };

  const submit = async e => {
    e.preventDefault();
    try {
      await api.post('/health', Object.fromEntries(Object.entries(form).map(([k, v]) => [k, v === '' ? '' : Number(v)])));
      setMessage('Health reading saved successfully.'); setForm(emptyForm); load();
    } catch (err) { setMessage(err.response?.data?.message || 'Could not save reading'); }
  };

  const remove = async id => { if (!confirm('Delete this reading?')) return; await api.delete(`/health/${id}`); load(); };
  const chartData = records.slice(0, 14).reverse().map(x => ({ date: new Date(x.recordedAt).toLocaleDateString(), heartRate: x.heartRate, spo2: x.spo2 }));

  return <div>
    <h1>{t('health')}</h1>
    <div className="card">
      <div className="section-heading"><div><h2>{t('healthReading')}</h2><p className="muted small">{t('voiceHint')}</p></div><button type="button" className={`voice-button ${listening ? 'listening' : ''}`} onClick={startVoice}>{listening ? '🎙️ Listening…' : '🎤 Speak Reading'}</button></div>
      <form className="form-grid" onSubmit={submit}>
        {[['heartRate',`${t('heartRate')} (BPM)`],['systolic',`${t('bloodPressure')} — systolic`],['diastolic',`${t('bloodPressure')} — diastolic`],['spo2',`${t('oxygen')} (%)`],['temperature',`${t('temperature')} (°F)`],['bloodSugar',t('sugar')],['weight',`${t('weight')} (kg)`]].map(([key,label]) => <input key={key} name={key} type="number" step="0.1" placeholder={label} value={form[key]} onChange={e => update(key,e.target.value)} />)}
        <button className="primary" type="submit">{t('save')} Reading</button>
      </form>
      {message && <p className="success">{message}</p>}
    </div>
    {chartData.length > 0 && <div className="card chart-card"><h2>{t('trendTitle')}</h2><ResponsiveContainer width="100%" height={280}><LineChart data={chartData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" /><YAxis /><Tooltip /><Legend /><Line type="monotone" dataKey="heartRate" name="Heart Rate" /><Line type="monotone" dataKey="spo2" name="SpO2" /></LineChart></ResponsiveContainer></div>}
    <div className="card"><h2>{t('history')}</h2><div className="table-wrap"><table><thead><tr><th>Date</th><th>Heart Rate</th><th>BP</th><th>SpO₂</th><th>Temp</th><th>Status</th><th></th></tr></thead><tbody>{records.map(r => <tr key={r._id}><td>{new Date(r.recordedAt).toLocaleString()}</td><td>{r.heartRate ?? '-'}</td><td>{r.systolic && r.diastolic ? `${r.systolic}/${r.diastolic}` : '-'}</td><td>{r.spo2 ?? '-'}%</td><td>{r.temperature ?? '-'}</td><td><span className={r.status === 'alert' ? 'badge alert' : 'badge'}>{r.status}</span></td><td><button className="danger" onClick={() => remove(r._id)}>{t('delete')}</button></td></tr>)}</tbody></table></div></div>
  </div>;
}
