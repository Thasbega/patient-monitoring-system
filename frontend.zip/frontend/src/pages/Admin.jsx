import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useLanguage } from '../i18n';

export default function Admin() {
  const { t } = useLanguage();
  const [overview, setOverview] = useState(null);
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'doctor', specialization: '' });
  const [error, setError] = useState('');
  const me = JSON.parse(localStorage.getItem('user') || '{}');

  const load = () => {
    api.get('/admin/overview').then(r => setOverview(r.data)).catch(() => {});
    api.get('/admin/users').then(r => setUsers(r.data)).catch(() => {});
  };
  useEffect(() => { load(); }, []);

  const createUser = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api.post('/admin/users', form);
      setForm({ name: '', email: '', password: '', role: 'doctor', specialization: '' });
      load();
    } catch (err) { setError(err.response?.data?.message || 'Could not create user'); }
  };

  const toggleActive = async (u) => {
    await api.patch(`/admin/users/${u._id}`, { isActive: !u.isActive });
    load();
  };
  const removeUser = async (id) => {
    if (!confirm('Delete this user account permanently?')) return;
    try { await api.delete(`/admin/users/${id}`); load(); }
    catch (err) { alert(err.response?.data?.message || 'Could not delete user'); }
  };

  return (
    <div>
      <h1>{t('admin')}</h1>
      {overview && (
        <section className="grid stats">
          <div className="card"><span>Patients</span><strong>{overview.patients}</strong></div>
          <div className="card"><span>Doctors</span><strong>{overview.doctors}</strong></div>
          <div className="card"><span>Appointments</span><strong>{overview.appointments}</strong></div>
          <div className="card"><span>Active Alerts</span><strong>{overview.alerts}</strong></div>
        </section>
      )}
      <div className="card">
        <h2>{t('createUser')}</h2>
        <form className="form-grid" onSubmit={createUser}>
          <input name="name" placeholder="Full name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
          <input name="email" type="email" placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
          <input name="password" type="password" placeholder="Password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required minLength={6} />
          <select name="role" value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
            <option value="doctor">Doctor</option>
            <option value="patient">Patient</option>
            <option value="admin">Admin</option>
          </select>
          {form.role === 'doctor' && <input name="specialization" placeholder="Specialization" value={form.specialization} onChange={e => setForm({ ...form, specialization: e.target.value })} />}
          <button className="primary" type="submit">Create User</button>
        </form>
        {error && <p className="error">{error}</p>}
      </div>
      <div className="card">
        <h2>{t('allUsers')}</h2>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {users.map(u => (
                <tr key={u._id}>
                  <td>{u.name}</td><td>{u.email}</td><td>{u.role}</td>
                  <td><span className={u.isActive === false ? 'badge alert' : 'badge'}>{u.isActive === false ? 'Deactivated' : 'Active'}</span></td>
                  <td className="row-actions">
                    <button className="secondary" onClick={() => toggleActive(u)}>{u.isActive === false ? 'Activate' : 'Deactivate'}</button>
                    {u._id !== me.id && <button className="danger" onClick={() => removeUser(u._id)}>Delete</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
