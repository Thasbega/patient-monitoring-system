import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useLanguage } from '../i18n';

const rank = { high: 0, moderate: 1, low: 2 };
export default function Patients() {
  const { t } = useLanguage();
  const [patients, setPatients] = useState([]);
  const navigate = useNavigate();
  useEffect(() => {
    api.get('/patients').then(async r => {
      const enriched = await Promise.all(r.data.map(async p => {
        try { const { data } = await api.get(`/insights/patient/${p._id}`); return { ...p, insights: data }; }
        catch { return { ...p, insights: null }; }
      }));
      enriched.sort((a,b) => rank[a.insights?.sevenDayRisk?.level || 'low'] - rank[b.insights?.sevenDayRisk?.level || 'low']);
      setPatients(enriched);
    }).catch(() => {});
  }, []);
  return (
    <div>
      <header className="topbar"><div><h1>{t('patients')}</h1><p className="muted">🔴 Critical first · 🟡 Attention · 🟢 Stable</p></div></header>
      <div className="grid patient-grid">
        {patients.map(p => {
          const level = p.insights?.sevenDayRisk?.level || 'low';
          const label = level === 'high' ? '🔴 Critical' : level === 'moderate' ? '🟡 Attention' : '🟢 Stable';
          return <div className="card" key={p._id}>
            <div style={{display:'flex',justifyContent:'space-between',gap:10,alignItems:'center'}}><h2>{p.name}</h2><span className={`badge ${level === 'high' ? 'alert' : ''}`}>{label}</span></div>
            <p>{p.email}</p><p>Gender: {p.gender || 'Not added'}</p><p>Blood group: {p.bloodGroup || 'Not added'}</p>
            <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
              <button className="secondary" onClick={() => navigate(`/patients/${p._id}`)}>{t('trendTitle')} / History</button>
              <button className="primary" onClick={() => navigate(`/medications?patientId=${p._id}`)}>💊 {t('prescribeMedication')}</button>
            </div>
          </div>;
        })}
      </div>
      {patients.length === 0 && <div className="card">No patients found.</div>}
    </div>
  );
}
