import React, { useState } from 'react';
import api from '../services/api';
import { useLanguage } from '../i18n';

export default function EmergencySOS() {
  const { t } = useLanguage();
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const activate = () => {
    if (!confirm(t('confirmSOS'))) return;
    setBusy(true); setError(''); setResult(null);

    const send = (position) => {
      const latitude = position?.coords?.latitude;
      const longitude = position?.coords?.longitude;
      api.post('/emergency/sos', { latitude, longitude })
        .then(r => setResult(r.data))
        .catch(e => setError(e.response?.data?.message || 'Could not activate SOS'))
        .finally(() => setBusy(false));
    };

    if (!navigator.geolocation) return send(null);
    navigator.geolocation.getCurrentPosition(send, () => send(null), { enableHighAccuracy: true, timeout: 8000 });
  };

  return <div className="sos-card card">
    <div>
      <span className="eyebrow">{t('emergencySupport')}</span>
      <h2>{t('needUrgent')}</h2>
      <p className="muted">{t('emergencyDescription')}</p>
    </div>
    <button className="sos-button" onClick={activate} disabled={busy}>{busy ? 'Activating…' : '🆘 Emergency SOS'}</button>
    {result && <div className="sos-success"><strong>SOS recorded.</strong> Your care team was notified in the app.{result.mapsUrl && <> <a href={result.mapsUrl} target="_blank" rel="noreferrer">Open live location</a></>}</div>}
    {error && <div className="error">{error}</div>}
  </div>;
}
