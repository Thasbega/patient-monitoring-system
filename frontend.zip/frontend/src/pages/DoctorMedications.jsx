import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../services/api';
import { useLanguage } from '../i18n';

export default function DoctorMedications() {
  const { t } = useLanguage();
  const [searchParams] = useSearchParams();
  const initialPatientId = searchParams.get('patientId') || '';

  const [patients, setPatients] = useState([]);
  const [prescriptions, setPrescriptions] = useState([]);
  const [selectedPatientId, setSelectedPatientId] = useState(initialPatientId);
  const [filterPatientId, setFilterPatientId] = useState('');
  const [form, setForm] = useState({
    patientId: initialPatientId,
    name: '',
    dosage: '',
    time: '',
    frequency: '',
    instructions: ''
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  // Load patients and prescriptions
  const loadPatients = async () => {
    try {
      const res = await api.get('/patients');
      setPatients(res.data);
      if (!form.patientId && res.data.length > 0 && !initialPatientId) {
        setForm(prev => ({ ...prev, patientId: res.data[0]._id }));
        setSelectedPatientId(res.data[0]._id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const loadPrescriptions = async () => {
    try {
      setLoading(true);
      const url = filterPatientId ? `/medications?patientId=${filterPatientId}` : '/medications';
      const res = await api.get(url);
      setPrescriptions(res.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPatients();
  }, []);

  useEffect(() => {
    loadPrescriptions();
  }, [filterPatientId]);

  // Voice fill listener
  useEffect(() => {
    const onVoiceFill = (event) => {
      const v = event.detail || {};
      setForm(prev => {
        let matchedPatientId = prev.patientId;
        if (v.patientName && patients.length > 0) {
          const lower = v.patientName.toLowerCase().trim();
          const found = patients.find(p => p.name.toLowerCase().includes(lower) || lower.includes(p.name.toLowerCase()));
          if (found) matchedPatientId = found._id;
        }
        return {
          ...prev,
          patientId: matchedPatientId,
          name: v.medicationName ?? prev.name,
          dosage: v.dosage ?? prev.dosage,
          frequency: v.frequency ?? prev.frequency,
          time: v.time ?? prev.time,
          instructions: v.instructions ?? prev.instructions
        };
      });
    };
    window.addEventListener('caretrack:voice-fill', onVoiceFill);
    return () => window.removeEventListener('caretrack:voice-fill', onVoiceFill);
  }, [patients]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');

    if (!form.patientId) {
      setError('Please select a patient.');
      return;
    }
    if (!form.name.trim()) {
      setError('Medication name is required.');
      return;
    }

    try {
      await api.post('/medications/send', form);
      const patientObj = patients.find(p => p._id === form.patientId);
      setMessage(`Prescription for ${form.name} sent to ${patientObj?.name || 'patient'} successfully!`);
      setForm(prev => ({
        ...prev,
        name: '',
        dosage: '',
        time: '',
        frequency: '',
        instructions: ''
      }));
      loadPrescriptions();
    } catch (err) {
      setError(err.response?.data?.message || 'Could not prescribe medication.');
    }
  };

  const toggleActive = async (m) => {
    try {
      await api.put(`/medications/${m._id}`, { active: !m.active });
      loadPrescriptions();
    } catch (err) {
      alert(err.response?.data?.message || 'Could not update status');
    }
  };

  const removeMedication = async (id) => {
    if (!confirm('Are you sure you want to cancel this prescription?')) return;
    try {
      await api.delete(`/medications/${id}`);
      loadPrescriptions();
    } catch (err) {
      alert(err.response?.data?.message || 'Could not remove prescription');
    }
  };

  const filteredItems = filterPatientId
    ? prescriptions.filter(p => String(p.patient?._id || p.patient) === filterPatientId)
    : prescriptions;

  return (
    <div>
      <div className="topbar">
        <div>
          <h1>💊 {t('doctorMedications')}</h1>
          <p className="muted">Prescribe medication reminders directly to patients with instant live alerts.</p>
        </div>
      </div>

      {/* Prescribe Form Card */}
      <div className="card">
        <h2>{t('prescribeMedication')}</h2>
        <form className="form-grid" onSubmit={handleSubmit}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label className="small muted"><strong>{t('selectPatient')} *</strong></label>
            <select
              name="patientId"
              value={form.patientId}
              onChange={e => setForm({ ...form, patientId: e.target.value })}
              required
            >
              <option value="">-- Choose Patient --</option>
              {patients.map(p => (
                <option key={p._id} value={p._id}>
                  {p.name} ({p.email})
                </option>
              ))}
            </select>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label className="small muted"><strong>{t('medicationName')} *</strong></label>
            <input
              id="medication-name"
              name="medicationName"
              placeholder="e.g. Paracetamol, Metformin"
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              required
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label className="small muted"><strong>{t('dosage')}</strong></label>
            <input
              id="medication-dosage"
              name="dosage"
              placeholder="e.g. 500 mg, 1 tablet"
              value={form.dosage}
              onChange={e => setForm({ ...form, dosage: e.target.value })}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label className="small muted"><strong>Reminder Time</strong></label>
            <input
              id="medication-time"
              name="time"
              type="time"
              value={form.time}
              onChange={e => setForm({ ...form, time: e.target.value })}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label className="small muted"><strong>{t('frequency')}</strong></label>
            <input
              id="medication-frequency"
              name="frequency"
              placeholder="e.g. Twice daily, Once at bedtime"
              value={form.frequency}
              onChange={e => setForm({ ...form, frequency: e.target.value })}
            />
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label className="small muted"><strong>{t('instructions')}</strong></label>
            <input
              id="medication-instructions"
              name="instructions"
              placeholder="e.g. After food with warm water"
              value={form.instructions}
              onChange={e => setForm({ ...form, instructions: e.target.value })}
            />
          </div>

          <button className="primary" type="submit" style={{ gridColumn: '1 / -1', marginTop: 10, fontSize: 16 }}>
            📤 Prescribe & Send Reminder to Patient
          </button>
        </form>

        {message && <p className="success" style={{ marginTop: 12, fontWeight: 600 }}>{message}</p>}
        {error && <p className="error" style={{ marginTop: 12, fontWeight: 600 }}>{error}</p>}

        <p className="muted small" style={{ marginTop: 14 }}>
          🎤 <strong>Voice Command:</strong> “patient Demo Patient, medicine Paracetamol, dosage 500 mg, frequency twice a day, time 8 pm, instructions after food” then say “save”.
        </p>
      </div>

      {/* Prescriptions List Card */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12, marginBottom: 16 }}>
          <h2>{t('doctorPrescriptions')}</h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span className="small muted">Filter Patient:</span>
            <select
              value={filterPatientId}
              onChange={e => setFilterPatientId(e.target.value)}
              style={{ padding: '6px 12px', borderRadius: 8, border: '1px solid #d7deea' }}
            >
              <option value="">All Patients</option>
              {patients.map(p => (
                <option key={p._id} value={p._id}>{p.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Patient</th>
                <th>Medication</th>
                <th>Dosage</th>
                <th>Time</th>
                <th>Frequency</th>
                <th>Instructions</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.map(m => {
                const patientName = m.patient?.name || (typeof m.patient === 'string' ? patients.find(p => p._id === m.patient)?.name : null) || 'Patient';
                const isTakenToday = m.lastTakenAt && new Date(m.lastTakenAt).toDateString() === new Date().toDateString();

                return (
                  <tr key={m._id}>
                    <td>
                      <strong>{patientName}</strong>
                      {m.patient?.email && <div className="muted small">{m.patient.email}</div>}
                    </td>
                    <td><strong style={{ color: '#1e40af' }}>{m.name}</strong></td>
                    <td>{m.dosage || '-'}</td>
                    <td>{m.time ? `⏰ ${m.time}` : '-'}</td>
                    <td>{m.frequency || '-'}</td>
                    <td><small className="muted">{m.instructions || '-'}</small></td>
                    <td>
                      <span className={m.active ? 'badge' : 'badge alert'}>
                        {m.active ? 'Active' : 'Paused'}
                      </span>
                      {isTakenToday && <div className="small success" style={{ marginTop: 4 }}>✅ Taken today</div>}
                    </td>
                    <td className="row-actions">
                      <button
                        className="secondary"
                        onClick={() => toggleActive(m)}
                        title={m.active ? 'Pause reminder' : 'Resume reminder'}
                      >
                        {m.active ? 'Pause' : 'Resume'}
                      </button>
                      <button
                        className="danger"
                        onClick={() => removeMedication(m._id)}
                        title="Cancel prescription"
                      >
                        Cancel
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filteredItems.length === 0 && (
                <tr>
                  <td colSpan={8} className="muted" style={{ textAlign: 'center', padding: 24 }}>
                    {loading ? 'Loading prescriptions…' : 'No prescriptions recorded yet.'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
