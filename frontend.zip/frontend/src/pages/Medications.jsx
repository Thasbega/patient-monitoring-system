import React from 'react';
import DoctorMedications from './DoctorMedications';
import MedicationReminders from './MedicationReminders';

export default function Medications() {
  const role = localStorage.getItem('role') || 'patient';

  if (role === 'doctor') {
    return <DoctorMedications />;
  }

  return <MedicationReminders />;
}
