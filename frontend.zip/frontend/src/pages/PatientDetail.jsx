import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, Legend } from 'recharts';
import api from '../services/api';
import { openPatientReport } from '../utils/report';
import { useLanguage } from '../i18n';

export default function PatientDetail() {
  const { t } = useLanguage();
  const { id } = useParams();
  const navigate = useNavigate();
  const [patient, setPatient] = useState(null);
  const [records, setRecords] = useState([]);
  const [error, setError] = useState('');
  const [insights, setInsights] = useState(null);
  const [notes, setNotes] = useState('');
  const [medications, setMedications] = useState([]);
  const [medForm, setMedForm] = useState({ name:'', dosage:'', time:'', frequency:'' });
  const [medMessage, setMedMessage] = useState('');
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    const onVoiceFill = (event) => {
      const v = event.detail || {};
      setMedForm(prev => ({
        ...prev,
        name: v.medicationName ?? prev.name,
        dosage: v.dosage ?? prev.dosage,
        frequency: v.frequency ?? prev.frequency,
        time: v.time ?? prev.time
      }));
    };
    window.addEventListener('caretrack:voice-fill', onVoiceFill);
    return () => window.removeEventListener('caretrack:voice-fill', onVoiceFill);
  }, []);

  useEffect(() => {
    api.get(`/patients/${id}`).then(r => setPatient(r.data)).catch(() => setError('Could not load patient'));
    api.get(`/health/patient/${id}`).then(r => setRecords(r.data)).catch(() => {});
    api.get(`/insights/patient/${id}`).then(r => setInsights(r.data)).catch(() => {});
    api.get(`/medications?patientId=${id}`).then(r => setMedications(r.data)).catch(() => {});
    api.get('/appointments').then(r => setAppointments(r.data.filter(a => String(a.patient?._id || a.patient) === String(id)))).catch(() => {});
  }, [id]);

  const sendMedication = async (e) => {
    e.preventDefault();
    setMedMessage('');
    try {
      await api.post('/medications/send', { patientId:id, ...medForm });
      setMedForm({ name:'', dosage:'', time:'', frequency:'' });
      const r = await api.get(`/medications?patientId=${id}`);
      setMedications(r.data);
      setMedMessage('Medication sent to patient successfully.');
    } catch (err) {
      setMedMessage(err.response?.data?.message || 'Could not send medication.');
    }
  };

  const chartData = records.slice(0, 14).reverse().map(x => ({
    date: new Date(x.recordedAt).toLocaleDateString(),
    heartRate: x.heartRate,
    spo2: x.spo2
  }));

  if (error) return <div className="card">{error}</div>;
  if (!patient) return <div className="card">Loading…</div>;

  return (
    <div>
      <button className="link-btn" onClick={() => navigate('/patients')}>&larr; {t('back')} {t('patients')}</button>
      <h1>{patient.name}</h1>
      <section className="grid stats">
        <div className="card"><span>Email</span><strong className="small">{patient.email}</strong></div>
        <div className="card"><span>Gender</span><strong>{patient.gender || 'Not added'}</strong></div>
        <div className="card"><span>Blood Group</span><strong>{patient.bloodGroup || 'Not added'}</strong></div>
        <div className="card"><span>Phone</span><strong className="small">{patient.phone || 'Not added'}</strong></div>
      </section>
      <div className="card" style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <button className="primary" onClick={() => navigate(`/messages?with=${patient._id}`)}>Message Patient</button>
        <button className="secondary" onClick={() => navigate(`/documents?patient=${patient._id}`)}>View Documents</button>
        <button className="secondary" onClick={() => openPatientReport({ patient, records, insights, notes, medications, appointments })}>📄 {t('report')}</button>
      </div>
      <div className="card">
        <h2>{t('doctorReportNotes')}</h2>
        <textarea rows={4} placeholder={t('reportNotePlaceholder')} value={notes} onChange={e => setNotes(e.target.value)} />
        {insights?.sevenDayRisk && <div className="notice"><strong>7-day monitoring risk:</strong> {insights.sevenDayRisk.label} — {insights.sevenDayRisk.statement}</div>}
        <button className="primary" onClick={() => openPatientReport({ patient, records, insights, notes, medications, appointments })}>{t('print')}</button>
      </div>
      <div className="card">
        <h2>💊 Prescribe Medication</h2>
        <p className="muted small">Send medication instructions directly to this patient. Only patients assigned to you through an appointment can receive prescriptions.</p>
        <form className="form-grid" onSubmit={sendMedication}>
          <input id="doctor-medication-name" name="medicationName" aria-label="Medication name" placeholder="Medicine name" required value={medForm.name} onChange={e=>setMedForm({...medForm,name:e.target.value})}/>
          <input id="doctor-medication-dosage" name="dosage" aria-label="Dosage" placeholder="Dosage (e.g. 500 mg)" value={medForm.dosage} onChange={e=>setMedForm({...medForm,dosage:e.target.value})}/>
          <input id="doctor-medication-time" name="time" aria-label="Time" type="time" value={medForm.time} onChange={e=>setMedForm({...medForm,time:e.target.value})}/>
          <input id="doctor-medication-frequency" name="frequency" aria-label="Frequency" placeholder="Frequency (e.g. twice a day)" value={medForm.frequency} onChange={e=>setMedForm({...medForm,frequency:e.target.value})}/>
          <button className="primary" type="submit">Send to Patient</button>
        </form>
        {medMessage && <p className={medMessage.includes('successfully') ? 'success' : 'error'}>{medMessage}</p>}
        <p className="muted small">🎤 Voice: “medicine name paracetamol, dosage 500 mg, frequency twice a day, time 8 pm” then say “save”.</p>
      </div>
      <div className="card">
        <h2>💊 Current Medications</h2>
        <div className="table-wrap"><table>
          <thead><tr><th>Name</th><th>Dosage</th><th>Time</th><th>Frequency</th><th>Source</th><th>Status</th></tr></thead>
          <tbody>
            {medications.map(m=><tr key={m._id}><td>{m.name}</td><td>{m.dosage||'-'}</td><td>{m.time||'-'}</td><td>{m.frequency||'-'}</td><td>{m.source==='doctor'?'Doctor':'Patient'}</td><td>{m.active?'Active':'Paused'}</td></tr>)}
            {!medications.length && <tr><td colSpan="6" className="muted">No medications yet.</td></tr>}
          </tbody>
        </table></div>
      </div>
      <div className="card chart-card">
        <h2>Health Trend</h2>
        {chartData.length === 0 ? <p className="muted">No health records yet.</p> : (
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="heartRate" name="Heart Rate" stroke="#2563eb" />
              <Line type="monotone" dataKey="spo2" name="SpO2" stroke="#16733a" />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
      <div className="card">
        <h2>Recent Readings</h2>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Date</th><th>Heart Rate</th><th>BP</th><th>SpO₂</th><th>Temp</th><th>Status</th></tr></thead>
            <tbody>
              {records.map(r => (
                <tr key={r._id}>
                  <td>{new Date(r.recordedAt).toLocaleString()}</td>
                  <td>{r.heartRate ?? '-'}</td>
                  <td>{r.systolic && r.diastolic ? `${r.systolic}/${r.diastolic}` : '-'}</td>
                  <td>{r.spo2 ?? '-'}%</td>
                  <td>{r.temperature ?? '-'}</td>
                  <td><span className={r.status === 'alert' ? 'badge alert' : 'badge'}>{r.status}</span></td>
                </tr>
              ))}
              {records.length === 0 && <tr><td colSpan={6} className="muted">No readings yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
