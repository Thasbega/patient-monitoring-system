import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useLanguage } from '../i18n';

const labels = { rising: 'Rising ↑', falling: 'Falling ↓', stable: 'Stable →', insufficient_data: 'Need more data' };

export default function Insights() {
  const { t } = useLanguage();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const load = () => api.get('/insights').then(r => { setData(r.data); setError(''); }).catch(e => setError(e.response?.data?.message || 'Could not load insights'));
  useEffect(() => { load(); }, []);
  if (error) return <div className="card error">{error}</div>;
  if (!data) return <div className="card">Loading health insights…</div>;
  const risk = data.sevenDayRisk;
  return <div>
    <header className="topbar"><div><h1>{t('aiRiskTitle')}</h1><p className="muted">Explainable pattern detection from recent health readings.</p></div><button className="secondary" onClick={load}>Refresh</button></header>
    <div className={`risk-banner risk-${risk?.level || 'low'}`}><div><span className="eyebrow">Next 7 days</span><h2>{risk?.label || 'Lower monitoring risk'}</h2><p>{risk?.statement}</p></div><div className="risk-icon">{risk?.level === 'high' ? '🔴' : risk?.level === 'moderate' ? '🟡' : '🟢'}</div></div>
    <div className="insight-hero card"><div><span className="eyebrow">Wellness monitoring score</span><div className="score">{data.wellnessScore ?? '--'}<small>/100</small></div><p>{data.summary}</p></div><div className={`score-ring ${data.level}`}><span>{data.level === 'good' ? 'Stable' : 'Monitor'}</span></div></div>
    <div className="card"><h2>Smart observations</h2><div className="insight-list">{data.insights.map((item,i)=><div className={`insight-item ${item.priority}`} key={i}><div><strong>{item.title}</strong><p>{item.detail}</p></div><span className="priority">{item.priority}</span></div>)}</div></div>
    <section className="grid stats">{Object.entries(data.trends || {}).filter(([,v]) => v !== 'insufficient_data').map(([key,value])=><div className="card" key={key}><span>{key === 'spo2' ? 'SpO₂' : key}</span><strong className={`trend-${value}`}>{labels[value] || value}</strong>{data.averages?.[key] != null && <small className="muted">Avg: {Number(data.averages[key]).toFixed(1)}</small>}</div>)}</section>
    <div className="card"><h2>{t('health')} — {t('recentTrend')}</h2><div className="mini-grid"><div><span>Heart rate</span><strong>{data.latest?.heartRate ?? '--'} BPM</strong></div><div><span>Blood pressure</span><strong>{data.latest?.systolic && data.latest?.diastolic ? `${data.latest.systolic}/${data.latest.diastolic}` : '--'}</strong></div><div><span>SpO₂</span><strong>{data.latest?.spo2 ?? '--'}%</strong></div><div><span>Blood sugar</span><strong>{data.latest?.bloodSugar ?? '--'}</strong></div></div></div>
    <div className="notice">{data.sevenDayRisk?.method} {data.disclaimer}</div>
  </div>;
}
