import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useLanguage } from '../i18n';

export default function MedicationReminders() {
  const { t } = useLanguage();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showSelfForm, setShowSelfForm] = useState(false);
  const [form, setForm] = useState({ name: '', dosage: '', time: '', frequency: '', instructions: '' });
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const load = () => {
    setLoading(true);
    api.get('/medications')
      .then(r => setItems(r.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();

    const onVoiceFill = (event) => {
      const v = event.detail || {};
      if (v.medicationName || v.dosage || v.frequency || v.time) {
        setShowSelfForm(true);
        setForm(prev => ({
          ...prev,
          name: v.medicationName ?? prev.name,
          dosage: v.dosage ?? prev.dosage,
          frequency: v.frequency ?? prev.frequency,
          time: v.time ?? prev.time,
          instructions: v.instructions ?? prev.instructions
        }));
      }
    };

    // Listener for voice "mark as taken" command
    const onVoiceTake = (event) => {
      const targetMed = event.detail?.medicineName;
      if (targetMed && items.length > 0) {
        const found = items.find(m => m.name.toLowerCase().includes(targetMed.toLowerCase()));
        if (found) {
          markAsTaken(found);
        }
      }
    };

    window.addEventListener('caretrack:voice-fill', onVoiceFill);
    window.addEventListener('caretrack:voice-take-med', onVoiceTake);
    return () => {
      window.removeEventListener('caretrack:voice-fill', onVoiceFill);
      window.removeEventListener('caretrack:voice-take-med', onVoiceTake);
    };
  }, [items]);

  const markAsTaken = async (med) => {
    try {
      await api.patch(`/medications/${med._id}/take`);
      setSuccessMsg(`✅ ${med.name} marked as taken for today!`);
      setTimeout(() => setSuccessMsg(''), 5000);
      load();
    } catch (err) {
      alert(err.response?.data?.message || 'Could not update medication status');
    }
  };

  const submitSelfMedication = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api.post('/medications', form);
      setForm({ name: '', dosage: '', time: '', frequency: '', instructions: '' });
      setShowSelfForm(false);
      setSuccessMsg('Personal medication reminder added successfully!');
      setTimeout(() => setSuccessMsg(''), 4000);
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Could not add medication');
    }
  };

  const toggleActive = async (m) => {
    try {
      await api.put(`/medications/${m._id}`, { active: !m.active });
      load();
    } catch (err) {
      alert(err.response?.data?.message || 'Could not update status');
    }
  };

  const remove = async (id) => {
    if (!confirm('Remove this reminder?')) return;
    try {
      await api.delete(`/medications/${id}`);
      load();
    } catch (err) {
      alert(err.response?.data?.message || 'Could not remove');
    }
  };

  // Sort schedule items by reminder time
  const activeItems = items.filter(m => m.active);
  const isTakenToday = (m) => m.lastTakenAt && new Date(m.lastTakenAt).toDateString() === new Date().toDateString();

  return (
    <div>
      <div className="topbar">
        <div>
          <h1>⏰ {t('medicationReminders')}</h1>
          <p className="muted">Track your daily medicines prescribed by your doctor and never miss a scheduled dose.</p>
        </div>
        <button
          className="secondary"
          onClick={() => setShowSelfForm(!showSelfForm)}
          style={{ display: 'flex', alignItems: 'center', gap: 6 }}
        >
          {showSelfForm ? '✖ Close Form' : `➕ ${t('addPersonalReminder')}`}
        </button>
      </div>

      {successMsg && (
        <div className="card" style={{ background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#166534', fontWeight: 600, padding: 14 }}>
          {successMsg}
        </div>
      )}

      {/* Optional Personal Reminder Form */}
      {showSelfForm && (
        <div className="card" style={{ border: '2px dashed #93c5fd' }}>
          <h2>➕ {t('addPersonalReminder')}</h2>
          <p className="muted small">Add vitamins, supplements, or personal OTC medicine reminders.</p>
          <form className="form-grid" onSubmit={submitSelfMedication}>
            <input
              id="medication-name"
              name="medicationName"
              placeholder={t('medicationName')}
              value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value })}
              required
            />
            <input
              id="medication-dosage"
              name="dosage"
              placeholder={t('dosage')}
              value={form.dosage}
              onChange={e => setForm({ ...form, dosage: e.target.value })}
            />
            <input
              id="medication-time"
              name="time"
              type="time"
              value={form.time}
              onChange={e => setForm({ ...form, time: e.target.value })}
            />
            <input
              id="medication-frequency"
              name="frequency"
              placeholder={t('frequency')}
              value={form.frequency}
              onChange={e => setForm({ ...form, frequency: e.target.value })}
            />
            <input
              id="medication-instructions"
              name="instructions"
              placeholder={t('instructions')}
              value={form.instructions}
              onChange={e => setForm({ ...form, instructions: e.target.value })}
            />
            <button className="primary" type="submit">
              {t('addMedicationBtn')}
            </button>
          </form>
          {error && <p className="error" style={{ marginTop: 10 }}>{error}</p>}
        </div>
      )}

      {/* Today's Schedule Card */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div>
            <h2>🗓️ Today’s Medication Schedule</h2>
            <p className="muted small">Mark your medicine as taken once you consume your dose.</p>
          </div>
          <span className="badge" style={{ fontSize: 13 }}>
            {activeItems.filter(isTakenToday).length} / {activeItems.length} Taken
          </span>
        </div>

        {activeItems.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '30px 10px', color: '#64748b' }}>
            <div style={{ fontSize: 40, marginBottom: 8 }}>💊</div>
            <p><strong>{t('noMedications')}</strong></p>
            <p className="small">Your doctor will prescribe medications for your health condition, or you can add personal reminders.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
            {activeItems.map(m => {
              const taken = isTakenToday(m);
              const isDoctor = m.source === 'doctor';
              const doctorName = m.prescribedBy?.name ? `Dr. ${m.prescribedBy.name}` : 'Doctor';

              return (
                <div
                  key={m._id}
                  style={{
                    border: taken ? '1px solid #bbf7d0' : '1px solid #dbeafe',
                    background: taken ? 'linear-gradient(135deg, #f0fdf4, #ffffff)' : 'linear-gradient(135deg, #eff6ff, #ffffff)',
                    borderRadius: 14,
                    padding: 18,
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
                  }}
                >
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                      <span
                        style={{
                          background: taken ? '#dcfce7' : '#dbeafe',
                          color: taken ? '#15803d' : '#1d4ed8',
                          padding: '4px 10px',
                          borderRadius: 20,
                          fontSize: 12,
                          fontWeight: 700
                        }}
                      >
                        ⏰ {m.time || 'Daily'}
                      </span>
                      <span className="small muted" style={{ fontSize: 11 }}>
                        {isDoctor ? '👨‍⚕️ Prescribed' : 'Self'}
                      </span>
                    </div>

                    <h3 style={{ margin: '6px 0 4px', fontSize: 18, color: '#172033' }}>{m.name}</h3>
                    <p style={{ margin: '2px 0 6px', color: '#4b5563', fontSize: 14 }}>
                      <strong>{m.dosage || 'Dose as directed'}</strong> {m.frequency ? `· ${m.frequency}` : ''}
                    </p>

                    {m.instructions && (
                      <p className="small" style={{ color: '#0369a1', background: '#e0f2fe', padding: '6px 10px', borderRadius: 8, margin: '8px 0' }}>
                        💡 {m.instructions}
                      </p>
                    )}

                    {isDoctor && (
                      <p className="muted small" style={{ margin: '6px 0 10px' }}>
                        Prescribed by: <strong>{doctorName}</strong>
                      </p>
                    )}
                  </div>

                  <div style={{ marginTop: 14 }}>
                    {taken ? (
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: 6,
                          background: '#dcfce7',
                          color: '#166534',
                          fontWeight: 700,
                          padding: '10px 14px',
                          borderRadius: 10,
                          fontSize: 14
                        }}
                      >
                        <span>✅</span> {t('takenToday')} ({new Date(m.lastTakenAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})
                      </div>
                    ) : (
                      <button
                        className="primary"
                        onClick={() => markAsTaken(m)}
                        style={{
                          width: '100%',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          gap: 8,
                          fontWeight: 600,
                          padding: 10,
                          background: '#16a34a'
                        }}
                      >
                        <span>✔</span> {t('markAsTaken')}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* All Prescriptions Table Card */}
      <div className="card">
        <h2>{t('allMedications')}</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Medicine Name</th>
                <th>Dosage</th>
                <th>Reminder Time</th>
                <th>Frequency</th>
                <th>Instructions</th>
                <th>Source</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map(m => {
                const isDoctor = m.source === 'doctor';
                const doctorName = m.prescribedBy?.name ? `Dr. ${m.prescribedBy.name}` : 'Doctor';

                return (
                  <tr key={m._id}>
                    <td>
                      <strong>{m.name}</strong>
                    </td>
                    <td>{m.dosage || '-'}</td>
                    <td>{m.time ? `⏰ ${m.time}` : '-'}</td>
                    <td>{m.frequency || '-'}</td>
                    <td><small className="muted">{m.instructions || '-'}</small></td>
                    <td>
                      {isDoctor ? (
                        <span style={{ color: '#1d4ed8', fontWeight: 600 }}>👨‍⚕️ {doctorName}</span>
                      ) : (
                        <span className="muted">Self</span>
                      )}
                    </td>
                    <td>
                      <span className={m.active ? 'badge' : 'badge alert'}>
                        {m.active ? t('active') : t('paused')}
                      </span>
                    </td>
                    <td className="row-actions">
                      {!isDoctor ? (
                        <>
                          <button className="secondary" onClick={() => toggleActive(m)}>
                            {m.active ? t('pause') : t('resume')}
                          </button>
                          <button className="danger" onClick={() => remove(m._id)}>
                            {t('delete')}
                          </button>
                        </>
                      ) : (
                        <button
                          className="secondary"
                          onClick={() => markAsTaken(m)}
                          title="Mark dose as taken"
                        >
                          ✔ {t('markAsTaken')}
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
              {items.length === 0 && (
                <tr>
                  <td colSpan={8} className="muted" style={{ textAlign: 'center', padding: 20 }}>
                    {loading ? 'Loading medications…' : t('noMedications')}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
