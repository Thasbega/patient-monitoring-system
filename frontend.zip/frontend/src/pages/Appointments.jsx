import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useLanguage } from '../i18n';

export default function Appointments() {
  const { t } = useLanguage();
  const [items, setItems] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [form, setForm] = useState({ doctorId: '', date: '', reason: '' });
  const [error, setError] = useState('');
  const role = localStorage.getItem('role');

  const load = () => api.get('/appointments').then(r => setItems(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);
  useEffect(() => {
    if (role === 'patient') api.get('/patients/doctors').then(r => setDoctors(r.data)).catch(() => {});
  }, [role]);

  const submit = async e => {
    e.preventDefault();
    setError('');
    try { await api.post('/appointments', form); setForm({ doctorId: '', date: '', reason: '' }); load(); }
    catch (err) { setError(err.response?.data?.message || 'Could not book'); }
  };

  const setStatus = async (id, status) => {
    await api.patch(`/appointments/${id}/status`, { status });
    load();
  };
  const cancel = async (id) => {
    if (!confirm('Cancel this appointment?')) return;
    await api.delete(`/appointments/${id}`);
    load();
  };

  return (
    <div>
      <h1>{t('appointments')}</h1>
      {role === 'patient' && (
        <div className="card">
          <h2>{t('bookAppointment')}</h2>
          <form className="form-grid" onSubmit={submit}>
            <select name="doctorId" value={form.doctorId} onChange={e => setForm({ ...form, doctorId: e.target.value })} required>
              <option value="">{t('selectDoctor')}</option>
              {doctors.map(d => <option key={d._id} value={d._id}>{d.name}{d.specialization ? ` — ${d.specialization}` : ''}</option>)}
            </select>
            <input name="date" type="datetime-local" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} required />
            <input name="reason" placeholder={t('reason')} value={form.reason} onChange={e => setForm({ ...form, reason: e.target.value })} />
            <button className="primary" type="submit">{t('book')}</button>
          </form>
          {error && <p className="error">{error}</p>}
        </div>
      )}
      <div className="card">
        <h2>{t('appointmentList')}</h2>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Date</th><th>Patient</th><th>Doctor</th><th>Reason</th><th>Status</th>{role !== 'admin' && <th></th>}</tr></thead>
            <tbody>
              {items.map(x => (
                <tr key={x._id}>
                  <td>{new Date(x.date).toLocaleString()}</td>
                  <td>{x.patient?.name}</td>
                  <td>{x.doctor?.name}</td>
                  <td>{x.reason || '-'}</td>
                  <td><span className={x.status === 'cancelled' ? 'badge alert' : 'badge'}>{x.status}</span></td>
                  <td className="row-actions">
                    {role === 'doctor' && x.status === 'pending' && <button className="secondary" onClick={() => setStatus(x._id, 'confirmed')}>Confirm</button>}
                    {role === 'doctor' && x.status === 'confirmed' && <button className="secondary" onClick={() => setStatus(x._id, 'completed')}>Mark Complete</button>}
                    {role === 'doctor' && ['pending', 'confirmed'].includes(x.status) && <button className="danger" onClick={() => setStatus(x._id, 'cancelled')}>Cancel</button>}
                    {role === 'patient' && ['pending', 'confirmed'].includes(x.status) && <button className="danger" onClick={() => cancel(x._id)}>Cancel</button>}
                  </td>
                </tr>
              ))}
              {items.length === 0 && <tr><td colSpan={6} className="muted">{t('noAppointments')}</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
