import React, { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../services/api';
import { getSocket } from '../services/socket';
import { useLanguage } from '../i18n';

export default function Messages() {
  const { t } = useLanguage();
  const [contacts, setContacts] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [thread, setThread] = useState([]);
  const [text, setText] = useState('');
  const [searchParams] = useSearchParams();
  const me = JSON.parse(localStorage.getItem('user') || '{}');
  const bottomRef = useRef(null);

  useEffect(() => {
    api.get('/messages/contacts').then(r => {
      setContacts(r.data);
      const preselect = searchParams.get('with');
      if (preselect && r.data.some(c => c._id === preselect)) setActiveId(preselect);
      else if (r.data.length && !activeId) setActiveId(r.data[0]._id);
    }).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!activeId) return;
    api.get(`/messages/${activeId}`).then(r => setThread(r.data)).catch(() => {});
  }, [activeId]);

  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    const onMsg = (msg) => {
      if (msg.sender._id === activeId || msg.sender._id === me.id) {
        setThread(prev => [...prev, msg]);
      }
    };
    socket.on('message:new', onMsg);
    return () => socket.off('message:new', onMsg);
  }, [activeId]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [thread]);

  const send = async (e) => {
    e.preventDefault();
    if (!text.trim() || !activeId) return;
    const { data } = await api.post('/messages', { receiverId: activeId, text });
    setThread(prev => [...prev, { ...data, sender: { _id: me.id, name: me.name } }]);
    setText('');
  };

  const activeContact = contacts.find(c => c._id === activeId);

  return (
    <div>
      <h1>{t('messages')}</h1>
      <div className="card chat-shell">
        <aside className="chat-contacts">
          {contacts.length === 0 && <p className="muted" style={{ padding: 16 }}>{t('noContacts')}</p>}
          {contacts.map(c => (
            <div key={c._id} className={`chat-contact ${c._id === activeId ? 'active' : ''}`} onClick={() => setActiveId(c._id)}>
              <strong>{c.name}</strong>
              <span className="muted">{c.role === 'doctor' ? (c.specialization || 'Doctor') : 'Patient'}</span>
            </div>
          ))}
        </aside>
        <section className="chat-window">
          {activeContact ? (
            <>
              <div className="chat-header"><strong>{activeContact.name}</strong> <span className="muted">({activeContact.role})</span></div>
              <div className="chat-messages">
                {thread.map(m => (
                  <div key={m._id} className={`chat-bubble ${(m.sender._id || m.sender) === me.id ? 'mine' : ''}`}>
                    <p>{m.text}</p>
                    <span className="muted">{new Date(m.createdAt).toLocaleTimeString()}</span>
                  </div>
                ))}
                <div ref={bottomRef} />
              </div>
              <form className="chat-input" onSubmit={send}>
                <input name="text" placeholder={t('typeMessage')} value={text} onChange={e => setText(e.target.value)} />
                <button className="primary" type="submit">{t('send')}</button>
              </form>
            </>
          ) : <p className="muted" style={{ padding: 16 }}>Select a contact to start chatting.</p>}
        </section>
      </div>
    </div>
  );
}
