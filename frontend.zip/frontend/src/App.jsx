import React, { useEffect, useState } from 'react';
import { Routes, Route, Link, useNavigate, useLocation, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Health from './pages/Health';
import Patients from './pages/Patients';
import PatientDetail from './pages/PatientDetail';
import Appointments from './pages/Appointments';
import Medications from './pages/Medications';
import DoctorMedications from './pages/DoctorMedications';
import MedicationReminders from './pages/MedicationReminders';
import Messages from './pages/Messages';
import Documents from './pages/Documents';
import Admin from './pages/Admin';
import Insights from './pages/Insights';
import EmergencySOS from './pages/EmergencySOS';
import NotificationBell from './components/NotificationBell';
import { getSocket, disconnectSocket } from './services/socket';
import { LanguageProvider, LanguageSelector, useLanguage } from './i18n';
import VoiceAssistant from './components/VoiceAssistant';

function Layout({ children, role: activeRole }) {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  const role = activeRole || localStorage.getItem('role') || 'patient';

  useEffect(() => {
    getSocket();
    return () => {};
  }, []);

  const logout = () => {
    disconnectSocket();
    localStorage.clear();
    window.dispatchEvent(new Event('caretrack:auth-change'));
    navigate('/login');
  };

  const isActive = (path) => (location.pathname === path ? 'active' : '');

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <h2>❤ CareTrack</h2>
        <p className="muted">{role.toUpperCase()}</p>
        <nav>
          <Link className={isActive('/')} to="/">{t('dashboard')}</Link>
          {role === 'patient' && <Link className={isActive('/health')} to="/health">{t('health')}</Link>}
          {role === 'patient' && <Link className={isActive('/insights')} to="/insights">{t('insights')} ✨</Link>}
          {role === 'patient' && <Link className={isActive('/emergency')} to="/emergency">{t('emergency')} 🆘</Link>}
          <Link className={isActive('/appointments')} to="/appointments">{t('appointments')}</Link>
          {role === 'patient' && (
            <Link className={isActive('/medications') || isActive('/medication-reminders')} to="/medications">
              ⏰ {t('medicationReminders')}
            </Link>
          )}
          {role === 'doctor' && (
            <Link className={isActive('/medications') || isActive('/doctor-medications')} to="/medications">
              💊 {t('doctorMedications')}
            </Link>
          )}
          {role === 'doctor' && <Link className={isActive('/patients')} to="/patients">{t('patients')}</Link>}
          <Link className={isActive('/documents')} to="/documents">{t('documents')}</Link>
          <Link className={isActive('/messages')} to="/messages">{t('messages')}</Link>
          {role === 'admin' && <Link className={isActive('/admin')} to="/admin">{t('admin')}</Link>}
        </nav>
        <button className="logout" onClick={logout}>{t('logout')}</button>
      </aside>
      <main className="content">
        <div className="content-topbar">
          <LanguageSelector compact />
          <NotificationBell />
        </div>
        {children}
        <VoiceAssistant />
      </main>
    </div>
  );
}

function AppRoutes() {
  const [token, setToken] = useState(() => localStorage.getItem('token'));
  const [role, setRole] = useState(() => localStorage.getItem('role') || 'patient');

  const syncAuth = () => {
    setToken(localStorage.getItem('token'));
    setRole(localStorage.getItem('role') || 'patient');
  };

  useEffect(() => {
    window.addEventListener('storage', syncAuth);
    window.addEventListener('caretrack:auth-change', syncAuth);
    return () => {
      window.removeEventListener('storage', syncAuth);
      window.removeEventListener('caretrack:auth-change', syncAuth);
    };
  }, []);

  return (
    <Routes>
      <Route
        path="/login"
        element={
          token ? (
            <Navigate to="/" replace />
          ) : (
            <Login onLoginSuccess={syncAuth} />
          )
        }
      />
      <Route
        path="*"
        element={
          token ? (
            <Layout role={role}>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/health" element={<Health />} />
                <Route path="/insights" element={<Insights />} />
                <Route path="/emergency" element={<EmergencySOS />} />
                <Route path="/appointments" element={<Appointments />} />
                <Route path="/medications" element={<Medications />} />
                <Route path="/medication-reminders" element={<MedicationReminders />} />
                <Route path="/doctor-medications" element={<DoctorMedications />} />
                <Route path="/patients" element={<Patients />} />
                <Route path="/patients/:id" element={<PatientDetail />} />
                <Route path="/documents" element={<Documents />} />
                <Route path="/messages" element={<Messages />} />
                <Route path="/admin" element={<Admin />} />
              </Routes>
            </Layout>
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />
    </Routes>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppRoutes />
    </LanguageProvider>
  );
}
