import React, { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useLanguage } from '../i18n';

// Navigation routes and extensive multilingual keywords (English, Tamil, Tanglish, Hindi, Telugu, Malayalam)
const routes = [
  {
    path: '/',
    labelKey: 'dashboard',
    keys: [
      'dashboard', 'home', 'go home', 'home page', 'main page', 'main menu',
      // Tamil & Tanglish
      'டாஷ்போர்டு', 'முகப்பு', 'முகப்பு பக்கம்', 'டாஷ்போர்டுக்கு போ', 'டாஷ்போர்ட்',
      'dashboard ku po', 'dashboard poga', 'dashboardக்கு போ', 'home ku po', 'home poga', 'dashboard open pannu', 'dashboard kaattu',
      // Other languages
      'डैशबोर्ड', 'डैशबोर्ड पर जाओ', 'होम',
      'డ్యాష్‌బోర్డ్', 'డ్యాష్‌బోర్డ్‌కి వెళ్లి', 'హోమ్',
      'ഡാഷ്ബോർഡ്', 'ഡാഷ്ബോർഡിലേക്ക് പോകൂ', 'ഹോം'
    ]
  },
  {
    path: '/health',
    labelKey: 'health',
    keys: [
      'health records', 'health record', 'health', 'vitals', 'records', 'health page', 'open health', 'vital signs',
      // Tamil & Tanglish
      'உடல்நல பதிவுகள்', 'உடல்நலம்', 'ஹெல்த்', 'ஹெல்த் ரெகார்ட்ஸ்', 'பதிவுகள்', 'ஹெல்த் பேஜ்',
      'health records ku po', 'health ku po', 'health poga', 'records ku po', 'sugar bp paakanum', 'health open pannu', 'health recordsக்கு போ',
      // Other languages
      'स्वास्थ्य रिकॉर्ड', 'स्वास्थ्य रिकॉर्ड खोलो', 'स्वास्थ्य',
      'ఆరోగ్య రికార్డులు', 'ఆరోగ్య రికార్డులకు వెళ్లండి', 'ఆరోగ్యం',
      'ആരോഗ്യ രേഖകൾ', 'ആരോഗ്യ രേഖകളിലേക്ക് പോകൂ', 'ആരോഗ്യം'
    ]
  },
  {
    path: '/insights',
    labelKey: 'insights',
    keys: [
      'ai risk', 'risk center', 'insights', 'ai risk center', 'health risk', 'risk', 'prediction', 'ai insights',
      // Tamil & Tanglish
      'அபாய மையம்', 'ஏஐ அபாய மையம்', 'ரிஸ்க் சென்டர்', 'ரிஸ்க்', 'நுண்ணறிவு', 'ஏஐ ரிஸ்க்',
      'ai risk ku po', 'risk ku po', 'risk center ku po', 'insights ku po', 'risk kaattu', 'ai poga', 'ai அபாய மையம்',
      // Other languages
      'एआई जोखिम', 'जोखिम केंद्र', 'जोखिम', 'इनसाइट्स',
      'AI రిస్క్', 'రిస్క్ సెంటర్', 'ఇన్‌సైట్స్',
      'AI റിസ്ക്', 'റിസ്ക് സെന്റർ', 'ഇൻസൈറ്റുകൾ'
    ]
  },
  {
    path: '/emergency',
    labelKey: 'emergency',
    keys: [
      'emergency', 'sos', 'emergency sos', 'urgent', 'help', 'call ambulance', 'sos call',
      // Tamil & Tanglish
      'அவசரம்', 'அவசர உதவி', 'எஸ் ஓ எஸ்', 'காப்பாத்து', 'உதவி', 'அவசர sos',
      'emergency ku po', 'sos ku po', 'sos pannu', 'emergency open pannu', 'urgent help', 'sos செய்',
      // Other languages
      'आपातकाल', 'एसओएस', 'मदद',
      'అత్యవసర', 'SOS', 'సహాయం',
      'അടിയന്തര', 'എസ്ഒഎസ്', 'സഹായം'
    ]
  },
  {
    path: '/appointments',
    labelKey: 'appointments',
    keys: [
      'appointments', 'appointment', 'booking', 'book appointment', 'doctor appointment', 'doctor booking', 'appointments page',
      // Tamil & Tanglish
      'சந்திப்புகள்', 'அப்பாயிண்ட்மெண்ட்', 'மருத்துவர் சந்திப்பு', 'முன்பதிவு', 'டாக்டர் பார்க்கணும்',
      'appointment ku po', 'appointment poga', 'appointments ku po', 'booking ku po', 'doctor appointment', 'appointment open pannu',
      // Other languages
      'अपॉइंटमेंट', 'अपॉइंटमेंट खोलो', 'मुलाकात',
      'అపాయింట్‌మెంట్లు', 'అపాయింట్‌మెంట్',
      'അപ്പോയിന്റ്മെന്റുകൾ', 'അപ്പോയിന്റ്മെന്റ്'
    ]
  },
  {
    path: '/medications',
    labelKey: 'medications',
    keys: [
      'medications', 'medication', 'medicine', 'medicines', 'prescriptions', 'prescription', 'medication reminders', 'reminders', 'pill reminder', 'my medications', 'doctor medications', 'doctor medicine',
      // Tamil & Tanglish
      'மருந்துகள்', 'மருந்து', 'மருந்து நினைவூட்டல்', 'மருத்துவர் மருந்துகள்', 'மருந்துச்சீட்டு', 'நினைவூட்டல்கள்', 'என் மருந்துகள்', 'மருந்து நேரம்',
      'medications ku po', 'medication ku po', 'medicine ku po', 'marunthu ku po', 'marunthukal', 'reminders ku po', 'medication reminders ku po', 'doctor marunthu', 'marunthu page', 'marunthu kaattu', 'marunthu reminder',
      // Other languages
      'दवाइयाँ', 'दवा', 'मेडिसिन', 'दवा रिमाइंडर', 'डॉक्टर दवाइयाँ',
      'మందులు', 'మందు', 'మందు రిమైండర్లు', 'డాక్టర్ మందులు',
      'മരുന്നുകൾ', 'മരുന്ന്', 'മരുന്ന് ഓർമ്മപ്പെടുത്തലുകൾ'
    ]
  },
  {
    path: '/patients',
    labelKey: 'patients',
    keys: [
      'patients', 'patient', 'my patients', 'patient list', 'patient records', 'view patients',
      // Tamil & Tanglish
      'நோயாளிகள்', 'நோயாளி', 'என் நோயாளிகள்', 'பேஷன்ட்ஸ்', 'நோயாளி பட்டியல்',
      'patients ku po', 'patients list ku po', 'patient page ku po', 'patients kaattu', 'patients poga', 'patient details',
      // Other languages
      'मेरे मरीज', 'मरीज', 'मरीजों की सूची',
      'నా రోగులు', 'రోగులు',
      'എന്റെ രോഗികൾ', 'രോഗികൾ'
    ]
  },
  {
    path: '/documents',
    labelKey: 'documents',
    keys: [
      'documents', 'document', 'medical documents', 'reports', 'files', 'uploads', 'test reports',
      // Tamil & Tanglish
      'ஆவணங்கள்', 'ஆவணம்', 'அறிக்கைகள்', 'டாக்குமெண்ட்ஸ்', 'மருத்துவ ஆவணங்கள்', 'கோப்புகள்',
      'documents ku po', 'document poga', 'reports ku po', 'files ku po', 'document open pannu', 'report paakanum',
      // Other languages
      'दस्तावेज़', 'दस्तावेज', 'रिपोर्ट्स',
      'పత్రాలు', 'రిపోర్టులు',
      'രേഖകൾ', 'റിപ്പോർട്ടുകൾ'
    ]
  },
  {
    path: '/messages',
    labelKey: 'messages',
    keys: [
      'messages', 'message', 'chat', 'inbox', 'conversation', 'message doctor', 'doctor chat', 'chat with doctor',
      // Tamil & Tanglish
      'செய்திகள்', 'செய்தி', 'சாட்', 'மெசேஜ்', 'மருத்துவர் சாட்', 'உரையாடல்',
      'messages ku po', 'chat ku po', 'message poga', 'doctor chat', 'chat open pannu', 'doctor ku message',
      // Other languages
      'संदेश', 'चैट', 'मैसेज',
      'సందేశాలు', 'చాట్',
      'സന്ദേശങ്ങൾ', 'ചാറ്റ്'
    ]
  },
  {
    path: '/admin',
    labelKey: 'admin',
    keys: [
      'admin', 'admin panel', 'manage users', 'system admin',
      // Tamil & Tanglish
      'நிர்வாகம்', 'அட்மின்', 'அட்மின் பேனல்',
      'admin ku po', 'admin panel ku po',
      // Other languages
      'एडमिन', 'एडमिन पैनल',
      'అడ్మిన్', 'అడ్మిన్ ప్యానెల్',
      'അഡ്മിൻ', 'അഡ്മിൻ പാനൽ'
    ]
  }
];

const fieldAliases = {
  name: ['name', 'full name', 'patient name', 'பெயர்', 'முழு பெயர்', 'नाम', 'पूरा नाम', 'పేరు', 'പേര്'],
  email: ['email', 'mail', 'மின்னஞ்சல்', 'ईमेल', 'ఇమెయిల్', 'ഇമെയിൽ'],
  password: ['password', 'passcode', 'கடவுச்சொல்', 'पासवर्ड', 'పాస్‌వర్డ్', 'പാസ്‌വേഡ്'],
  specialization: ['specialization', 'speciality', 'சிறப்பு', 'विशेषज्ञता', 'ప్రత్యేకత', 'സ്പെഷ്യലൈസേഷൻ'],
  patientName: ['patient', 'patient name', 'நோயாளி', 'நோயாளி பெயர்', 'मरीज', 'రోగి', 'രോഗി'],
  medicationName: ['medication name', 'medicine name', 'medicine', 'medication', 'drug name', 'மருந்தின் பெயர்', 'மருந்து பெயர்', 'மருந்து', 'marunthu', 'दवा का नाम', 'दवाई का नाम', 'मेडिसिन নাম', 'మందు పేరు', 'മരുന്നിന്റെ പേര്'],
  dosage: ['dosage', 'dose', 'strength', 'mg', 'ml', 'tablet', 'tablets', 'அளவு', 'மருந்தளவு', 'खुराक', 'डोज', 'మాత్ర', 'మోతాదు', 'ഡോസ്'],
  frequency: ['frequency', 'how often', 'times a day', 'daily', 'அடிக்கடி', 'எத்தனை முறை', 'ஆवृत्ति', 'फ्रीक्वेंसी', 'ఫ్రీక్వెన్సీ', 'ആവൃത്തി'],
  instructions: ['instructions', 'instruction', 'directions', 'notes', 'வழிமுறைகள்', 'குறிப்பு', 'निर्देश', 'సూచనలు', 'നിർദ്ദേശങ്ങൾ'],
  systolic: ['systolic', 'upper bp', 'top bp', 'systolic bp', 'blood pressure upper', 'சிஸ்டாலிக்', 'ரத்த அழுத்தம் மேல்பக்கம்', 'सिस्टोलिक', 'ऊपरी बीपी', 'సిస్టోలిక్', 'ബ്ലഡ് പ്രഷർ മുകളിലെ'],
  diastolic: ['diastolic', 'lower bp', 'bottom bp', 'diastolic bp', 'blood pressure lower', 'டயஸ்டாலிக்', 'ரத்த அழுத்தம் கீழ்பக்கம்', 'डायस्टोलिक', 'नीचे का बीपी', 'డయాస్టాలిక్', 'ബ്ലഡ് പ്രഷർ താഴത്തെ'],
  heartRate: ['heart rate', 'pulse', 'bpm', 'இதய துடிப்பு', 'நாடித்துடிப்பு', 'हार्ट रेट', 'पल्स', 'హార్ట్ రేట్', 'പൾസ്'],
  spo2: ['spo2', 'sp o2', 'oxygen', 'oxygen saturation', 'ஆக்சிஜன்', 'ஆக்சிஜன் அளவு', 'ऑक्सीजन', 'ఆక్సిజన్', 'ഓക്സിജൻ'],
  bloodSugar: ['blood sugar', 'sugar', 'glucose', 'சர்க்கரை', 'ரத்த சர்க்கரை', 'ब्लड शुगर', 'शुगर', 'బ్లడ్ షుగర్', 'ബ്ലഡ് ഷുഗർ'],
  temperature: ['temperature', 'temp', 'வெப்பநிலை', 'तापमान', 'టెంపరేచర్', 'താപനില'],
  weight: ['weight', 'எடை', 'वजन', 'బరువు', 'ഭാരം'],
  reason: ['reason', 'purpose', 'காரணம்', 'நோக்கம்', 'कारण', 'కారణం', 'കാരണം'],
  text: ['message', 'text', 'note', 'doctor note', 'செய்தி', 'குறிப்பு', 'संदेश', 'సందేశం', 'സന്ദേശം'],
  date: ['date', 'appointment date', 'தேதி', 'तारीख', 'తేదీ', 'തീയതി'],
  time: ['time', 'நேரம்', 'समय', 'సమయం', 'സമയം']
};

function norm(s) {
  return String(s || '')
    .toLowerCase()
    .replace(/[“”‘’]/g, '')
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function allAliases(key) {
  return fieldAliases[key] || [];
}

function findInput(key) {
  const aliases = allAliases(key).map(norm);
  const controls = [...document.querySelectorAll('input, textarea, select')];
  return controls.find(el => {
    const text = norm([el.name, el.id, el.placeholder, el.getAttribute('aria-label')].filter(Boolean).join(' '));
    return aliases.some(a => text.includes(a) || a.includes(text));
  });
}

function setNativeValue(el, value) {
  if (!el) return false;
  const proto = el.tagName === 'TEXTAREA'
    ? HTMLTextAreaElement.prototype
    : el.tagName === 'SELECT'
    ? HTMLSelectElement.prototype
    : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
  setter?.call(el, value);
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
  return true;
}

export function parseForm(rawText) {
  const s = norm(rawText);
  const result = {};

  // Blood Pressure: "bp 120 80", "120 by 80", "ரத்த அழுத்தம் 120 80"
  const bp = s.match(/(?:bp|blood pressure|bloodpressure|ரத்த அழுத்தம்|ब्लड प्रेशर|రక్తపోటు|ബ്ലഡ് പ്രഷർ)[^\d]*(\d{2,3})\s*(?:by|over|\/|to|க்கு|से|పై|బై|\s)\s*(\d{2,3})/i);
  if (bp) {
    result.systolic = bp[1];
    result.diastolic = bp[2];
  }

  const numPatterns = [
    ['bloodSugar', /(?:sugar|glucose|blood sugar|சர்க்கரை|ब्लड शुगर|शुगर|బ్లడ్ షుగర్|ബ്ലഡ് ഷുഗർ)[^\d]*(\d+(?:\.\d+)?)/i],
    ['heartRate', /(?:heart rate|pulse|bpm|இதய துடிப்பு|நாடித்துடிப்பு|हार्ट रेट|पल्स|హార్ట్ రేట్|പൾസ്)[^\d]*(\d+(?:\.\d+)?)/i],
    ['spo2', /(?:spo2|sp o2|oxygen|ஆக்சிஜன்|ऑक्सीजन|ఆక్సిజన్|ഓക്സിജൻ)[^\d]*(\d+(?:\.\d+)?)/i],
    ['temperature', /(?:temperature|temp|வெப்பநிலை|तापमान|టెంపరేచర్|താപനില)[^\d]*(\d+(?:\.\d+)?)/i],
    ['weight', /(?:weight|எடை|वजन|బరువు|ഭാരം)[^\d]*(\d+(?:\.\d+)?)/i]
  ];
  numPatterns.forEach(([key, re]) => {
    const m = s.match(re);
    if (m) result[key] = m[1];
  });

  // Patient selector voice parsing (for doctor prescribing)
  const patientMatch = s.match(/(?:patient|patient name|நோயாளி|நோயாளி பெயர்|மரீஜ்|ரோகி)\s*(?:is|:|என்பது|है|అయితే)?\s*([a-z0-9\s]+?)(?=\s+(?:medicine|medication|drug|marunthu|dosage|frequency|time|instructions)\b|\s*,|$)/i);
  if (patientMatch) {
    result.patientName = patientMatch[1].trim();
  }

  // Medication parsing
  const medMatch = s.match(/(?:medication name|medicine name|medicine|medication|drug name|drug|marunthu|மருந்தின் பெயர்|மருந்து பெயர்|மருந்து|தவா)\s*(?:is|:|என்பது|है|అయితే)?\s*([a-z0-9\s-]+?)(?=\s+(?:dosage|dose|strength|அளவு|frequency|daily|times|time|at|instructions|வழிமுறைகள்)\b|\s*,|$)/i);
  if (medMatch) {
    result.medicationName = medMatch[1].trim();
  }

  const doseMatch = s.match(/(?:dosage|dose|strength|அளவு|மருந்தளவு|खुराक|डोज)\s*(?:is|:|என்பது|है|అయితే)?\s*([\d.]+\s*(?:mg|mcg|g|ml|tablet|tablets|capsule|capsules)?)/i);
  if (doseMatch) {
    result.dosage = doseMatch[1].trim();
  } else {
    // Check for inline dose like "500 mg" or "1 tablet"
    const inlineDose = s.match(/\b(\d+(?:\.\d+)?\s*(?:mg|mcg|g|ml|tablet|tablets|capsule|capsules))\b/i);
    if (inlineDose) result.dosage = inlineDose[1].trim();
  }

  const freqMatch = s.match(/(?:frequency|how often|times a day|அடிக்கடி|எத்தனை முறை|ஆवृत्ति)\s*(?:is|:|என்பது|है|అయితే)?\s*([a-z0-9\s]+?)(?=\s+(?:time|at|நேரம்|instructions|வழிமுறைகள்)\b|\s*,|$)/i);
  if (freqMatch) {
    result.frequency = freqMatch[1].trim();
  } else if (/\b(twice daily|twice a day|once daily|once a day|thrice daily|3 times a day|at bedtime|daily)\b/i.test(s)) {
    const inlineFreq = s.match(/\b(twice daily|twice a day|once daily|once a day|thrice daily|3 times a day|at bedtime|daily)\b/i);
    if (inlineFreq) result.frequency = inlineFreq[1].trim();
  }

  const instMatch = s.match(/(?:instructions|instruction|notes|வழிமுறைகள்|निर्देश)\s*(?:is|:|என்பது|है|అయితే)?\s*(.+)$/i);
  if (instMatch) {
    result.instructions = instMatch[1].trim();
  } else if (/\b(after food|before food|after meals|before meals|with water|with milk|சாப்பிட்ட பிறகு|உணவுக்குப் பின்)\b/i.test(s)) {
    const inlineInst = s.match(/\b(after food|before food|after meals|before meals|with water|with milk|சாப்பிட்ட பிறகு|உணவுக்குப் பின்)\b/i);
    if (inlineInst) result.instructions = inlineInst[1].trim();
  }

  // Time parsing
  const timeMatch = s.match(/(?:time|at|நேரம்|समय|సమయం|സമയം)\s*(?:is|:|என்பது|है|అయితే)?\s*(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)/i);
  if (timeMatch) {
    let raw = timeMatch[1].trim().toLowerCase();
    const tm = raw.match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/);
    if (tm) {
      let h = Number(tm[1]);
      const min = tm[2] || '00';
      if (tm[3] === 'pm' && h < 12) h += 12;
      if (tm[3] === 'am' && h === 12) h = 0;
      result.time = `${String(h).padStart(2, '0')}:${min}`;
    }
  }

  // Appointment reason or text
  const reasonMatch = s.match(/(?:reason|purpose|காரணம்|நோக்கம்|कारण)\s*(?:is|:|என்பது|है)?\s*(.+)$/i);
  if (reasonMatch) result.reason = reasonMatch[1].trim();

  const textMatch = s.match(/(?:message|text|chat|note|செய்தி|குறிப்பு|संदेश)\s*(?:is|:|என்பது|है)?\s*(.+)$/i);
  if (textMatch) result.text = textMatch[1].trim();

  return result;
}

export default function VoiceAssistant() {
  const { language, t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();

  const [open, setOpen] = useState(false);
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [status, setStatus] = useState('');
  const recognitionRef = useRef(null);

  // Spoken feedback through browser SpeechSynthesis
  const speak = (text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = language || 'en-IN';
      u.rate = 1.0;
      window.speechSynthesis.speak(u);
    }
  };

  const start = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      setStatus(t('voiceUnsupported'));
      setOpen(true);
      return;
    }
    if (listening) {
      recognitionRef.current?.stop();
      return;
    }

    const r = new SR();
    r.lang = language || 'en-IN';
    r.interimResults = true;
    r.continuous = false;

    r.onstart = () => {
      setListening(true);
      setOpen(true);
      setStatus(t('listening'));
    };
    r.onend = () => setListening(false);
    r.onerror = (e) => {
      setListening(false);
      if (e.error !== 'no-speech') {
        setStatus(t('noCommand'));
      }
    };
    r.onresult = (e) => {
      const text = [...e.results].map(x => x[0].transcript).join(' ');
      setTranscript(text);
      if (!e.results[e.results.length - 1].isFinal) return;
      handleCommand(text);
    };

    recognitionRef.current = r;
    r.start();
  };

  const handleCommand = (raw) => {
    const text = norm(raw);
    if (!text) return;

    // 1. Check for Logout command
    if (/(logout|log out|sign out|exit|வெளியேறு|லாக் அவுட்|लॉग आउट|లాగ్ అవుట్|പുറത്തുകടക്കുക)/i.test(text)) {
      localStorage.clear();
      navigate('/login');
      const msg = language.startsWith('ta') ? 'வெளியேறினீர்கள்' : 'Logged out';
      setStatus(msg);
      speak(msg);
      return;
    }

    // 2. Check for "Mark medicine as taken" (Patient voice action)
    const takenMatch = text.match(/(?:mark|took|taken|consumed|சாப்பிட்டேன்|எடுத்துக்கொண்டேன்|eduthen|eduthuten)\s*(.+?)(?:\s*(?:as taken|taken|சாப்பிட்டேன்|எடுத்துக்கொண்டேன்|eduthen)|$)/i)
      || text.match(/(.+?)\s*(?:taken|took|எடுத்துக்கொண்டேன்|சாப்பிட்டேன்|eduthen|eduthuten)/i);

    if (takenMatch && (/(take|taken|took|எடுத்து|சாப்பிட்ட|eduthen)/i.test(text))) {
      const medName = takenMatch[1].replace(/(?:as|medicine|marunthu|மருந்து|தவா)\b/gi, '').trim();
      if (medName) {
        window.dispatchEvent(new CustomEvent('caretrack:voice-take-med', { detail: { medicineName: medName } }));
        const msg = language.startsWith('ta')
          ? `${medName} மருந்து எடுக்கப்பட்டதாக குறிக்கப்பட்டது`
          : `Marked ${medName} as taken`;
        setStatus(`✅ ${msg}`);
        speak(msg);
        return;
      }
    }

    // 3. Check for Save / Submit / Prescribe command
    if (/(save|submit|prescribe|send|சேமி|சமர்ப்பி|அனுப்பு|பரிந்துரை|செய்|सेव|जमा|भेजें|సేవ్|సమర్పించు|സേവ്)/i.test(text)) {
      const form = document.querySelector('form');
      const submit = form?.querySelector('button[type="submit"]') || form?.querySelector('.primary');
      if (submit) {
        submit.click();
        const msg = language.startsWith('ta') ? 'படிவம் சேமிக்கப்பட்டது' : t('saved');
        setStatus(`✅ ${msg}`);
        speak(msg);
        return;
      }
    }

    // 4. Navigation matching across all routes
    // Find best matching route:
    // A route matches if any of its keys is an exact match, starts with it, ends with it,
    // or is included as a distinct phrase.
    let matchedRoute = null;

    for (const r of routes) {
      const foundKey = r.keys.find(k => {
        const nk = norm(k);
        return (
          text === nk ||
          text.includes(` ${nk} `) ||
          text.startsWith(`${nk} `) ||
          text.endsWith(` ${nk}`) ||
          text.includes(nk)
        );
      });
      if (foundKey) {
        matchedRoute = r;
        break;
      }
    }

    if (matchedRoute) {
      navigate(matchedRoute.path);
      const label = t(matchedRoute.labelKey) || matchedRoute.path.replace('/', '') || 'Dashboard';
      const msg = language.startsWith('ta')
        ? `${label} பக்கத்திற்கு செல்கிறேன்`
        : `${t('opened')} ${label}`;
      setStatus(`🧭 ${msg}`);
      speak(msg);
      return;
    }

    // 5. Form field autofill (Medications, Health readings, Appointments, Messages)
    const values = parseForm(raw);
    let count = 0;

    Object.entries(values).forEach(([key, value]) => {
      const el = findInput(key);
      if (el) {
        setNativeValue(el, value);
        count++;
      }
    });

    // Also match select dropdown options (e.g. Patient dropdown in DoctorMedications or Doctor in Appointments)
    if (values.patientName) {
      const patientSelect = document.querySelector('select[name="patientId"]');
      if (patientSelect) {
        const option = [...patientSelect.options].find(o =>
          norm(o.textContent).includes(norm(values.patientName)) || norm(values.patientName).includes(norm(o.textContent))
        );
        if (option) {
          setNativeValue(patientSelect, option.value);
          count++;
        }
      }
    }

    [...document.querySelectorAll('select')].forEach(select => {
      const match = [...select.options].find(o => o.value && text.includes(norm(o.textContent)));
      if (match) {
        setNativeValue(select, match.value);
        count++;
      }
    });

    // Broadcast event for customized page state handlers (Medications, Health, etc.)
    window.dispatchEvent(new CustomEvent('caretrack:voice-fill', { detail: values }));

    if (values.medicationName || values.dosage || values.frequency || values.time || values.instructions) {
      count++;
    }

    if (count > 0) {
      const msg = language.startsWith('ta')
        ? 'படிவ விவரங்கள் நிரப்பப்பட்டன. சரிபார்த்து சேமிக்கவும்.'
        : t('filled');
      setStatus(`✍️ ${msg}`);
      speak(msg);
    } else {
      setStatus(t('noCommand'));
    }
  };

  useEffect(() => () => recognitionRef.current?.stop(), []);

  // Helpful quick command chips for user in current language
  const quickSuggestions = language.startsWith('ta')
    ? ['டாஷ்போர்டு', 'மருந்துகள்', 'சந்திப்புகள்', 'உடல்நல பதிவுகள்', 'அவசரம்', 'சேமி']
    : ['Dashboard', 'Medications', 'Appointments', 'Health Records', 'Emergency', 'Save'];

  return (
    <div className="voice-assistant-wrap">
      {open && (
        <div className="voice-panel card">
          <div className="voice-panel-head">
            <div>
              <strong>🎤 {t('voice')}</strong>
              <small>{language.startsWith('ta') ? 'பக்கத்தின் பெயரை சொல்லுங்கள் அல்லது படிவத்தை பேசுங்கள்.' : t('voiceHint')}</small>
            </div>
            <button className="link-btn" onClick={() => setOpen(false)} style={{ fontSize: 20 }}>×</button>
          </div>

          {listening && (
            <div className="voice-wave">
              <span /><span /><span /><span /><span />
            </div>
          )}

          {transcript && (
            <div className="voice-transcript">
              <strong>Heard:</strong> “{transcript}”
            </div>
          )}

          {status && <div className="voice-status">{status}</div>}

          {/* Quick Voice Chips */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, margin: '10px 0 6px' }}>
            {quickSuggestions.map((sug, idx) => (
              <span
                key={idx}
                onClick={() => handleCommand(sug)}
                style={{
                  fontSize: 11,
                  background: '#f1f5f9',
                  color: '#334155',
                  padding: '3px 8px',
                  borderRadius: 12,
                  cursor: 'pointer',
                  border: '1px solid #e2e8f0'
                }}
                title="Click to test command"
              >
                {sug}
              </span>
            ))}
          </div>

          <button
            className={`voice-main ${listening ? 'listening' : ''}`}
            onClick={start}
            title={listening ? 'Stop listening' : 'Start speaking'}
          >
            {listening ? `🎙️ ${t('stop')}` : '🎤'}
          </button>
        </div>
      )}

      <button
        className={`voice-fab ${listening ? 'listening' : ''}`}
        onClick={() => {
          setOpen(true);
          start();
        }}
        aria-label="Voice Assistant"
        title="Voice Assistant"
      >
        🎤
      </button>
    </div>
  );
}
