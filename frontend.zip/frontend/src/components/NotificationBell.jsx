import React, { useEffect, useRef, useState } from 'react';
import api from '../services/api';
import { getSocket } from '../services/socket';

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [unread, setUnread] = useState(0);
  const boxRef = useRef(null);

  const load = () => {
    api.get('/notifications').then(r => setItems(r.data)).catch(() => {});
    api.get('/notifications/unread-count').then(r => setUnread(r.data.count)).catch(() => {});
  };

  useEffect(() => {
    load();
    const socket = getSocket();
    if (!socket) return;
    const onNew = () => load();
    socket.on('notification:new', onNew);
    return () => socket.off('notification:new', onNew);
  }, []);

  useEffect(() => {
    const onClick = (e) => { if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const markRead = async (id) => {
    await api.patch(`/notifications/${id}/read`);
    load();
  };
  const markAllRead = async () => {
    await api.patch('/notifications/read-all');
    load();
  };

  return (
    <div className="bell-wrap" ref={boxRef}>
      <button className="bell-btn" onClick={() => setOpen(o => !o)} aria-label="Notifications">
        🔔{unread > 0 && <span className="bell-badge">{unread > 9 ? '9+' : unread}</span>}
      </button>
      {open && (
        <div className="bell-dropdown">
          <div className="bell-header">
            <strong>Notifications</strong>
            {unread > 0 && <button className="link-btn" onClick={markAllRead}>Mark all read</button>}
          </div>
          <div className="bell-list">
            {items.length === 0 && <p className="muted" style={{ padding: '12px 16px' }}>No notifications yet.</p>}
            {items.map(n => (
              <div key={n._id} className={`bell-item ${n.read ? '' : 'unread'}`} onClick={() => !n.read && markRead(n._id)}>
                <strong>{n.title}</strong>
                <p>{n.message}</p>
                <span className="muted">{new Date(n.createdAt).toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
