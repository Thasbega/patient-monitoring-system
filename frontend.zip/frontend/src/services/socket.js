import { io } from 'socket.io-client';

let socket = null;

// Lazily create (or reuse) a single authenticated socket connection.
// Called after login and again on app load whenever a token is present.
export function getSocket() {
  const token = localStorage.getItem('token');
  if (!token) return null;

  if (socket && socket.connected) return socket;

  if (socket) {
    socket.disconnect();
  }

  socket = io(import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000', {
    auth: { token }
  });

  return socket;
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
}
