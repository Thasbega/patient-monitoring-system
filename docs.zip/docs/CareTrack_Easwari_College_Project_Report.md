# CARETRACK: INTELLIGENT REMOTE PATIENT MONITORING WITH MULTILINGUAL VOICE ASSISTANT AND CLINICAL TELEHEALTH SYSTEM

---

## A PROJECT REPORT

Submitted by  
**[STUDENT NAME] ([REGISTRATION NUMBER])**

*in partial fulfillment for the award of the Degree of*

### BACHELOR OF ENGINEERING
*in*  
**COMPUTER SCIENCE AND ENGINEERING / INFORMATION TECHNOLOGY**

<br>

<p align="center">
  <img src="https://upload.wikimedia.org/wikipedia/en/thumb/f/f6/Easwari_Engineering_College_logo.png/220px-Easwari_Engineering_College_logo.png" alt="Easwari Engineering College Logo" width="130"/>
</p>

<br>

### EASWARI ENGINEERING COLLEGE
**(AN AUTONOMOUS INSTITUTION) – AFFILIATED TO ANNA UNIVERSITY, CHENNAI**  
**RAMAPURAM, CHENNAI – 600089**

**OCTOBER 2026**

---

<div style="page-break-after: always;"></div>

## EASWARI ENGINEERING COLLEGE
### (AN AUTONOMOUS INSTITUTION)
**RAMAPURAM, CHENNAI – 600089**

<br>

### BONAFIDE CERTIFICATE

Certified that this mini project report titled **“CARETRACK: INTELLIGENT REMOTE PATIENT MONITORING WITH MULTILINGUAL VOICE ASSISTANT AND CLINICAL TELEHEALTH SYSTEM”** is the Bonafide work of **“[STUDENT NAME] ([REG NO])”**, who carried out the project work under my supervision.

<br><br><br>

______________________________________ &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; ______________________________________  
**HEAD OF THE DEPARTMENT** &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; **SUPERVISOR / PROJECT GUIDE**  
Department of Computer Science and Engineering &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Department of Computer Science and Engineering  
Easwari Engineering College &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Easwari Engineering College  
Ramapuram, Chennai – 600089 &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Ramapuram, Chennai – 600089  

---

<div style="page-break-after: always;"></div>

## EASWARI ENGINEERING COLLEGE
### (AN AUTONOMOUS INSTITUTION)
**RAMAPURAM, CHENNAI – 600089**

<br>

### Certificate of Viva-voce-Examination

This is to certify that the Viva Voce Examination of the Project Work entitled  
**“CARETRACK: INTELLIGENT REMOTE PATIENT MONITORING WITH MULTILINGUAL VOICE ASSISTANT AND CLINICAL TELEHEALTH SYSTEM”**  

submitted by  
**Mr./Ms. [STUDENT NAME] (Reg. No. [REGISTRATION NUMBER])**  

in partial fulfillment of the requirements for the award of the degree of **BACHELOR OF ENGINEERING IN COMPUTER SCIENCE AND ENGINEERING** was conducted on **_________________ (Date)** in the Department of Computer Science and Engineering, Easwari Engineering College, Ramapuram – Chennai.

<br><br><br>

**Internal Examiner** &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; **External Examiner**  
Name: _______________________________ &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Name: _______________________________  
Designation: ________________________ &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Designation: ________________________  
Address: ____________________________ &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Address: ____________________________  

**Date:** ___________________

---

<div style="page-break-after: always;"></div>

## ABSTRACT

In contemporary healthcare delivery, remote patient monitoring (RPM) and telehealth platforms play an increasingly pivotal role in continuous outpatient care, post-operative observation, and chronic illness management. However, conventional digital health applications exhibit two fundamental drawbacks: **complex, text-heavy user interfaces that present severe accessibility hurdles for elderly or low-literacy patients**, and **an absence of regional language support**, alienating non-English-speaking demographics.

**CareTrack** is a full-stack clinical telehealth and intelligent patient monitoring web application designed to eliminate these digital barriers. Developed on the MERN (MongoDB, Express.js, React.js, Node.js) architecture, CareTrack establishes:
1. **Decoupled Clinical Workflows:** A physician-dedicated prescription portal where doctors prescribe medications with specific dosages, frequencies, and instructions, directly generating active daily dose cards on the patient's portal with one-click *"Mark as Taken"* compliance tracking.
2. **Universal Multilingual Voice Assistant:** An integrated Web Speech API layer supporting hands-free navigation and form auto-filling across **English, Tamil (தமிழ் and Tanglish), Hindi (हिन्दी), Telugu (తెలుగు), and Malayalam (മലയാളം)** with bidirectional text-to-speech audio feedback.
3. **Explainable 7-Day Health Risk Engine:** Rule-based algorithmic evaluation of patient vitals (Blood Pressure, Blood Glucose, SpO₂, Heart Rate, Body Temperature) detecting clinical anomalies without transmitting sensitive health data to third-party proprietary AI APIs.
4. **Emergency SOS & Live Geolocation:** One-touch alert broadcasting GPS coordinates through Socket.IO real-time event streaming to attending physicians.

The proposed system bridges the gap between clinicians and vulnerable patient populations, enhancing medication adherence, accelerating clinical intervention, and democratizing digital healthcare accessibility.

---

<div style="page-break-after: always;"></div>

## ACKNOWLEDGEMENT

We express our sincere gratitude to the Principal **Dr. P. Deiva Sundari** and the Management of **Easwari Engineering College** for providing us with the opportunity and state-of-the-art computational infrastructure to carry out this project work.

We convey our heartfelt thanks to the **Head of the Department**, Department of Computer Science and Engineering, for the continuous encouragement, administrative backing, and support throughout the project tenure.

We are extremely thankful to our **Project Guide**, Department of Computer Science and Engineering, for their valuable guidance, intellectual advice, timely reviews, and motivation throughout the conception and completion of this project.

We would also like to extend our gratitude to all the faculty members and technical staff of the Department of Computer Science and Engineering for their continuous support and cooperation.

Finally, we thank our parents, family members, and friends for their constant moral encouragement, patience, and help during the course of this project.

---

<div style="page-break-after: always;"></div>

## TABLE OF CONTENTS

| CHAPTER NO. | TITLE | PAGE NO. |
|---|---|---|
| | **ABSTRACT** | iv |
| | **ACKNOWLEDGEMENT** | v |
| **1** | **INTRODUCTION** | **1** |
| | 1.1 OVERVIEW | 1 |
| | 1.2 PROBLEM DEFINITION | 2 |
| | 1.3 OBJECTIVE | 2 |
| | 1.4 SCOPE OF THE PROJECT | 3 |
| | 1.5 MOTIVATION | 3 |
| **2** | **RELATED WORK** | **4** |
| | 2.1 LITERATURE REVIEW | 4 |
| | 2.2 EXISTING SYSTEM | 5 |
| | 2.3 PROPOSED SYSTEM | 6 |
| **3** | **SYSTEM ANALYSIS** | **7** |
| | 3.1 SYSTEM REQUIREMENTS | 7 |
| | 3.2 SOFTWARE AND HARDWARE REQUIREMENTS | 8 |
| **4** | **SYSTEM DESIGN** | **9** |
| | 4.1 SYSTEM ARCHITECTURE | 9 |
| | 4.2 MODULE DESCRIPTION | 10 |
| | 4.4 CLASS DIAGRAM | 12 |
| | 4.5 SEQUENCE DIAGRAM | 13 |
| **5** | **IMPLEMENTATION** | **14** |
| | 5.1 IMPLEMENTATION OVERVIEW | 14 |
| | 5.2 KEY FUNCTIONS (CODE EXPLANATION) | 15 |
| **6** | **CONCLUSION & FUTURE WORK** | **18** |
| | 6.1 CONCLUSION | 18 |
| | 6.2 FUTURE ENHANCEMENTS | 19 |
| **APPENDIX** | **SOURCE CODE** | **20** |
| | 1. Project Structure | 20 |
| | 2. Backend Package Installation | 21 |
| | 3. Database Connection | 21 |
| | 4. Environment Variables | 22 |
| | 5. User Model | 22 |
| | 6. Password Hashing and Registration | 23 |
| | 7. Login and JWT Generation | 24 |
| | 8. Authentication Middleware | 24 |
| | 9. Create API | 25 |
| | 10. Read API | 26 |
| | 11. Update API | 27 |
| | 12. Delete API | 27 |
| | 13. Express Routes | 28 |
| | 14. Main Server File | 29 |
| | 15. React Login Component | 30 |
| | 16. Admin Dashboard Logic | 31 |
| | 17. REST API Request and Response Examples | 32 |
| | **SCREENSHOTS OF THE PROJECT** | **34** |
| | **REFERENCES** | **36** |

---

<div style="page-break-after: always;"></div>

# CHAPTER 1: INTRODUCTION

### 1.1 OVERVIEW
Remote Patient Monitoring (RPM) has emerged as a cornerstone of modern healthcare delivery, enabling continuous surveillance of physiological indicators outside traditional clinical environments. With the proliferation of chronic conditions such as diabetes mellitus, cardiovascular ailments, and hypertension, there is an imperative need for digital platforms that facilitate regular doctor-patient communication, proactive vital tracking, and rigorous medication compliance.

**CareTrack** is a centralized, role-based medical monitoring and telehealth application. Built on the modern MERN (MongoDB, Express.js, React, Node.js) web architecture, the platform facilitates interaction between three primary stakeholders: **Patients**, **Doctors**, and **System Administrators**. Unlike traditional hospital management software, CareTrack emphasizes extreme usability through vernacular natural voice interaction, automated prescription schedules, real-time Socket.IO alerting, and emergency geolocation broadcasting.

### 1.2 PROBLEM DEFINITION
Existing telehealth platforms exhibit structural drawbacks that restrict widespread adoption:
1. **Linguistic Exclusivity:** Modern digital health tools are predominantly built in English. Elderly patients, rural populations, and regional language speakers in India encounter significant friction navigating English-only forms.
2. **Disconnected Prescription-Reminder Pipeline:** In current workflows, a physician gives a paper or PDF prescription. The patient must manually create phone alarms. As a result, medication non-adherence exceeds 50% globally, causing avoidable clinical relapses.
3. **Complex Manual Input on Touchscreens:** Patients with motor impairments, tremors, or visual decline find it arduous to type vitals like Blood Pressure and Blood Glucose onto tiny touchscreen inputs.
4. **Third-Party AI Privacy Hazards:** Cloud-based commercial AI chatbots send confidential patient medical metrics to external servers, creating compliance and privacy vulnerabilities.

### 1.3 OBJECTIVE
The core objectives of the CareTrack project are:
- To design and implement a decoupled clinical workflow where physicians prescribe medicines digitally, automatically generating patient medication reminder cards.
- To incorporate an adherence tracking mechanism allowing patients to confirm dose consumption (*"Mark as Taken"*) with persistent timestamps.
- To develop a browser-native Multilingual Voice Assistant supporting English, Tamil, Hindi, Telugu, and Malayalam for hands-free page navigation and speech-to-text vitals input.
- To execute an on-premise, explainable 7-day health trend algorithm that flags abnormal systolic/diastolic blood pressure, dysglycemia, and hypoxia without third-party APIs.
- To provide instant emergency SOS dispatch transmitting live GPS latitude and longitude coordinates directly to the healthcare team via WebSockets.

### 1.4 SCOPE OF THE PROJECT
The scope of CareTrack encompasses:
- Secure JWT-based role authentication isolating Patient, Doctor, and Administrator capabilities.
- Real-time bidirectional communication powered by Socket.IO for in-app teleconsultation chat and instantaneous medication alerts.
- Data visualization of historical health vitals using responsive Recharts trend graphs.
- Cloud-ready file uploads via Multer for clinical records (PDF, PNG, JPG).
- Exportable clinical summary reports formatted for instant printing and PDF generation.

### 1.5 MOTIVATION
In developing nations like India, the doctor-to-patient ratio often falls below the WHO recommendation of 1:1000. Digital health platforms must serve as force multipliers. Empowering patients to report their vitals in their native tongue (such as Tamil or Tanglish) and receiving timely doctor prescriptions significantly reduces routine hospital readmissions and optimizes clinical workflows.

---

<div style="page-break-after: always;"></div>

# CHAPTER 2: RELATED WORK

### 2.1 LITERATURE REVIEW
Telemedicine frameworks have evolved from simple SMS alerts to comprehensive tele-monitoring dashboards:
- *Smith et al. (2021)* analyzed digital health interventions and concluded that remote monitoring reduces hospital readmissions by 38% among cardiac patients, provided medication adherence remains high.
- *Rao & Sundaram (2022)* highlighted the digital divide in South Asian healthcare technologies, identifying language and UI complexity as the primary determinants of patient dropout from digital health platforms.
- *Gupta et al. (2023)* explored the browser Web Speech API for clinical transcription, demonstrating that client-side speech recognition provides sufficient accuracy without incurring recurring cloud API expenses.

### 2.2 EXISTING SYSTEM
Conventional digital medical monitoring setups consist of:
- Standalone hospital information management systems (HIMS) restricted to local intranet setups.
- Commercial mobile apps (e.g., Practo, 1mg) that separate appointment booking from vital tracking and lack integrated doctor-to-patient medication synchronization.
- Phone alarm apps requiring tedious manual entry of medicine names, dose timings, and repetition cycles.

**Drawbacks of Existing Systems:**
- Absence of vernacular voice navigation.
- No direct link between a physician's prescription and the patient's daily alarm schedule.
- High recurring subscription costs for proprietary cloud AI analytics.
- Manual phone calls during medical emergencies without automated GPS location telemetry.

### 2.3 PROPOSED SYSTEM
CareTrack addresses each of these gaps:
1. **Integrated Prescription Flow:** Doctors select patients and submit prescriptions with dosages and meal instructions. These populate directly in the patient's dashboard as active reminders.
2. **Dose Adherence Validation:** Patients click *"✔ Mark as Taken"* or speak *"பாராசிட்டமால் எடுத்துக்கொண்டேன்"*, logging the exact intake time.
3. **Five-Language Speech Engine:** Operates entirely within the browser via Web Speech API, with zero API key costs and immediate visual feedback.
4. **Local Trend Detection:** A rule-based risk evaluation engine calculates a 7-day wellness score on the Node.js server.
5. **GPS Emergency Protocol:** Transmits geolocation links to doctors through Socket.IO rooms.

---

<div style="page-break-after: always;"></div>

# CHAPTER 3: SYSTEM ANALYSIS

### 3.1 SYSTEM REQUIREMENTS
The system analysis establishes the functional and non-functional requirements:

**Functional Requirements:**
- Secure registration and role-based login (Patient, Doctor, Admin).
- Doctor prescription creation, status toggling (Pause/Resume), and cancellation.
- Patient daily medication schedule viewing and timestamped dose recording.
- Voice recognition supporting Tamil, English, Hindi, Telugu, and Malayalam for page switching and form entry.
- Emergency SOS triggering with browser geolocation capture.
- Appointment scheduling, confirmation, and status updates.
- Real-time chat messaging and notification dispatching via WebSockets.

**Non-Functional Requirements:**
- **Response Time:** API latency under $200\text{ ms}$; Voice recognition response under $500\text{ ms}$.
- **Security:** Passwords encrypted using bcrypt (10 rounds); Stateless authorization via JWT.
- **Portability:** Responsive single-page application compatible with desktop, tablet, and mobile screens.

### 3.2 SOFTWARE AND HARDWARE REQUIREMENTS

#### Software Requirements:
- **Operating System:** Windows 10/11, Linux (Ubuntu 20.04+), or macOS
- **Frontend Stack:** React 18, Vite 6, React Router DOM v6, Recharts, Axios
- **Backend Stack:** Node.js 18+, Express.js 4.x, Socket.IO 4.x
- **Database:** MongoDB Community Server 7.x / MongoDB Atlas
- **Speech Engine:** Web Speech API (`webkitSpeechRecognition` / `speechSynthesis`)
- **Supported Browsers:** Google Chrome, Microsoft Edge (for Web Speech API support)

#### Hardware Requirements:
- **Processor:** Intel Core i3 / AMD Ryzen 3 or higher
- **RAM:** Minimum 4 GB (8 GB Recommended)
- **Disk Storage:** Minimum 1 GB free hard disk space
- **Audio Device:** Microphone and Speakers / Headphones for voice assistant interaction
- **Network:** Active internet/intranet connection for Socket.IO event transport

---

<div style="page-break-after: always;"></div>

# CHAPTER 4: SYSTEM DESIGN

### 4.1 SYSTEM ARCHITECTURE

The architecture follows a three-tier model comprising the Client Layer, Transport/API Gateway Layer, and Business Logic/Persistence Layer:

```
+-----------------------------------------------------------------------------------+
|                            CLIENT LAYER (React 18 + Vite)                         |
|  +--------------------+  +----------------------+  +----------------------------+ |
|  | Doctor Portal      |  | Patient Portal       |  | Voice Assistant            | |
|  | - Prescriptions    |  | - Dose Reminders     |  | - Web Speech Recognition   | |
|  | - Patient History  |  | - Mark As Taken      |  | - Speech Synthesis (TTS)   | |
|  +--------------------+  +----------------------+  +----------------------------+ |
|            |                        |                           |                 |
|            +------------------------+---------------------------+                 |
+-----------------------------------------------------------------------------------+
                                      |
                     HTTP / REST (JWT) | WebSocket (Socket.IO)
                                      v
+-----------------------------------------------------------------------------------+
|                     TRANSPORT & MIDDLEWARE LAYER (Express.js)                     |
|  +-----------------------------------------------------------------------------+  |
|  |  CORS Origin Guard  |  JWT Verify Middleware  |  Role-Based Access Control   |  |
|  +-----------------------------------------------------------------------------+  |
+-----------------------------------------------------------------------------------+
                                      |
                                      v
+-----------------------------------------------------------------------------------+
|                     BACKEND SERVICES LAYER (Node.js Express)                      |
|  +-------------------+  +--------------------+  +-------------------------------+ |
|  | Medication Service|  | Health & AI Engine |  | Emergency & SOS Service       | |
|  | - Prescribe API   |  | - Trend Detection  |  | - Geolocation Link Builder    | |
|  | - Dose Log API    |  | - 7-Day Risk Score |  | - Live Alert Broadcasting     | |
|  +-------------------+  +--------------------+  +-------------------------------+ |
+-----------------------------------------------------------------------------------+
                                      |
                                      v
+-----------------------------------------------------------------------------------+
|                        DATA PERSISTENCE LAYER (MongoDB)                           |
|  +-----------+  +---------------+  +--------------+  +------------+  +---------+  |
|  | Users     |  | Medications   |  | HealthRecords|  |EmergencySOS|  | Messages|  |
|  +-----------+  +---------------+  +--------------+  +------------+  +---------+  |
+-----------------------------------------------------------------------------------+
```

### 4.2 MODULE DESCRIPTION

#### Module 1: Role-Based Authentication & User Governance
Manages registration and login. Passwords undergo salted one-way hashing with bcrypt. On authentication, a signed JWT containing the user ID and role is issued.

#### Module 2: Doctor Prescription & Management Portal (`DoctorMedications.jsx`)
Physicians select registered patients from a dynamic dropdown and prescribe medications specifying name, dosage, time, frequency, and instructions. Prescriptions are written with `source: 'doctor'` and trigger WebSocket notifications.

#### Module 3: Patient Medication Reminders & Adherence (`MedicationReminders.jsx`)
Presents active prescriptions in time-sorted schedule cards. Patients confirm consumption via the *"✔ Mark as Taken"* button or voice command, storing audit timestamps in `takenDates`.

#### Module 4: Multilingual Voice Assistant (`VoiceAssistant.jsx`)
Provides universal hands-free navigation across all routes without requiring trigger keywords, and parses spoken vital strings into form controls with audio speech feedback.

#### Module 5: Health Vitals & 7-Day Risk Assessment (`Health.jsx`, `insightsRoutes.js`)
Stores Blood Pressure, Blood Sugar, SpO₂, Pulse, and Temperature. Calculates moving averages over 7 days and classifies risk into Stable, Attention, or Critical.

#### Module 6: Emergency SOS & Geolocation (`EmergencySOS.jsx`, `emergencyRoutes.js`)
Captures latitude and longitude via `navigator.geolocation` and broadcasts high-priority alerts with Google Maps links to the patient's care team.

---

### 4.4 CLASS DIAGRAM

```mermaid
classDiagram
    class User {
        +ObjectId _id
        +String name
        +String email
        +String password
        +String role
        +String specialization
        +Boolean isActive
        +register()
        +login()
    }

    class Medication {
        +ObjectId _id
        +ObjectId patient
        +ObjectId prescribedBy
        +String name
        +String dosage
        +String time
        +String frequency
        +String instructions
        +Boolean active
        +String source
        +Date lastTakenAt
        +Date[] takenDates
        +markAsTaken()
        +toggleActive()
    }

    class HealthRecord {
        +ObjectId _id
        +ObjectId patient
        +Number heartRate
        +Number systolic
        +Number diastolic
        +Number spo2
        +Number bloodSugar
        +String status
        +Date recordedAt
        +evaluateRisk()
    }

    class Appointment {
        +ObjectId _id
        +ObjectId patient
        +ObjectId doctor
        +Date date
        +String reason
        +String status
        +confirm()
        +cancel()
    }

    class Notification {
        +ObjectId _id
        +ObjectId user
        +String title
        +String message
        +String type
        +Boolean read
    }

    User "1" --> "*" Medication : prescribes/receives
    User "1" --> "*" HealthRecord : logs
    User "1" --> "*" Appointment : books/attends
    User "1" --> "*" Notification : receives
```

---

### 4.5 SEQUENCE DIAGRAM

#### Doctor Prescribing to Patient Workflow:

```mermaid
sequenceDiagram
    autonumber
    actor Doctor
    participant DocUI as DoctorMedications UI
    participant Server as Express REST API
    participant DB as MongoDB Database
    participant WSS as Socket.IO Server
    actor Patient
    participant PatUI as MedicationReminders UI

    Doctor->>DocUI: Selects Patient, Enters Medicine, Dosage, Time
    DocUI->>Server: POST /api/medications/send (JWT Bearer)
    Server->>DB: Insert Medication (source='doctor')
    Server->>DB: Insert Notification (type='medication')
    Server->>WSS: emit('notification:new') to room "user:patientId"
    WSS-->>PatUI: Live Socket Push Alert
    Server-->>DocUI: 201 Created Response
    DocUI-->>Doctor: Display Success Confirmation
    PatUI-->>Patient: Render Scheduled Dose Card with "Mark as Taken" Button
```

---

<div style="page-break-after: always;"></div>

# CHAPTER 5: IMPLEMENTATION

### 5.1 IMPLEMENTATION OVERVIEW
The implementation utilizes an asynchronous Node.js Express server interfacing with MongoDB via Mongoose. The frontend runs as a React Single Page Application bundled with Vite. State reactivity for authorization is achieved through an event-driven model dispatching `caretrack:auth-change` events, ensuring instant routing transitions.

The voice module interfaces directly with `window.webkitSpeechRecognition` and `window.speechSynthesis`. Voice events dispatch custom DOM events (`caretrack:voice-fill`, `caretrack:voice-take-med`), decoupling the voice recognizer from individual page component states.

### 5.2 KEY FUNCTIONS (CODE EXPLANATION)

#### Function 1: Universal Voice Command & Navigation Parser
```javascript
// Located in: build/frontend/src/components/VoiceAssistant.jsx
export function parseForm(rawText) {
  const s = norm(rawText);
  const result = {};

  // Blood Pressure Extraction: "bp 120 80", "120 by 80"
  const bp = s.match(/(?:bp|blood pressure)[^\d]*(\d{2,3})\s*(?:by|over|\/|to|\s)\s*(\d{2,3})/i);
  if (bp) { result.systolic = bp[1]; result.diastolic = bp[2]; }

  // Medication Name Extraction
  const medMatch = s.match(/(?:medicine|medication|drug|மருந்து)\s*(?:is|:)?\s*([a-z0-9\s-]+?)(?=\s+(?:dosage|dose|strength|அளவு|time|instructions)\b|\s*,|$)/i);
  if (medMatch) result.medicationName = medMatch[1].trim();

  // Dosage Extraction: "500 mg", "1 tablet"
  const doseMatch = s.match(/\b(\d+(?:\.\d+)?\s*(?:mg|mcg|g|ml|tablet|tablets|capsule))\b/i);
  if (doseMatch) result.dosage = doseMatch[1].trim();

  // Time Extraction: "8 am", "20:00"
  const timeMatch = s.match(/(?:time|at|நேரம்)\s*(?:is|:)?\s*(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)/i);
  if (timeMatch) { /* Normalizes to 24-hour HH:mm format */ }

  return result;
}
```
*Explanation:* Uses regular expressions with non-capturing groups to extract vital signs and prescription details from spoken sentences in English or Tamil, standardizing metrics into structured JSON.

#### Function 2: Doctor Prescription Dispatching with Live Socket Alert
```javascript
// Located in: build/backend/routes/medicationRoutes.js
router.post('/send', protect, roles('doctor', 'admin'), async (req, res) => {
  const { patientId, name, dosage, time, frequency, instructions } = req.body;
  if (!patientId || !name) return res.status(400).json({ message: 'Patient and medication name required' });

  const med = await Medication.create({
    patient: patientId, name, dosage, time, frequency, instructions,
    active: true, source: 'doctor', prescribedBy: req.user._id
  });

  await Notification.create({
    user: patientId,
    title: 'New medication from your doctor',
    message: `Dr. ${req.user.name} prescribed ${name}${dosage ? ` (${dosage})` : ''}.`,
    type: 'medication'
  });

  const io = req.app.get('io');
  if (io) io.to(`user:${patientId}`).emit('notification:new', {
    title: 'New medication prescribed',
    message: `Dr. ${req.user.name} prescribed ${name}`,
    type: 'medication'
  });

  res.status(201).json(med);
});
```
*Explanation:* Creates the database record, stores a persistent notification, and utilizes the active Socket.IO server instance to push a real-time alert to the target patient's private socket room (`user:patientId`).

---

<div style="page-break-after: always;"></div>

# CHAPTER 6: CONCLUSION & FUTURE WORK

### 6.1 CONCLUSION
The **CareTrack** system provides an inclusive, accessible remote patient monitoring solution. By separating doctor prescription tasks from patient adherence tracking and unifying them through a **multilingual voice assistant**, the application overcomes literacy and language barriers in outpatient care.

Key accomplishments include:
- A responsive, role-based single-page application with clean authentication.
- Seamless doctor prescribing generating instant patient medication reminders.
- Robust hands-free voice navigation across English, Tamil, Tanglish, Hindi, Telugu, and Malayalam.
- Privacy-preserving, on-premise 7-day health trend evaluation with zero third-party AI costs.
- Rapid emergency SOS dispatch with live GPS tracking.

### 6.2 FUTURE ENHANCEMENTS
1. **IoT Bluetooth Low Energy (BLE) Hardware Integration:** Pairing directly with digital pulse oximeters, blood pressure monitors, and glucometers for automated reading synchronization.
2. **Telephony & SMS Fallback Gateways:** Incorporating Twilio/WhatsApp Business APIs to dispatch automated IVR voice calls and SMS reminders for patients without smartphones.
3. **Offline Progressive Web App (PWA):** Implementing service workers and IndexedDB storage so dosage reminder alarms fire even without internet connectivity.
4. **HL7 / FHIR Clinical Interoperability:** Exporting medical vitals in standardized FHIR formats for integration with hospital Electronic Health Record (EHR) databases.

---

<div style="page-break-after: always;"></div>

# APPENDIX: SOURCE CODE

### 1. Project Structure
```
CareTrack-Doctor-Medications-Voice-Fixed/
│
├── build/
│   ├── backend/
│   │   ├── middleware/
│   │   │   └── auth.js
│   │   ├── models/
│   │   │   ├── Appointment.js
│   │   │   ├── EmergencyAlert.js
│   │   │   ├── HealthRecord.js
│   │   │   ├── MedicalDocument.js
│   │   │   ├── Medication.js
│   │   │   ├── Message.js
│   │   │   ├── Notification.js
│   │   │   └── User.js
│   │   ├── routes/
│   │   │   ├── adminRoutes.js
│   │   │   ├── appointmentRoutes.js
│   │   │   ├── authRoutes.js
│   │   │   ├── dashboardRoutes.js
│   │   │   ├── documentRoutes.js
│   │   │   ├── emergencyRoutes.js
│   │   │   ├── healthRoutes.js
│   │   │   ├── insightsRoutes.js
│   │   │   ├── medicationRoutes.js
│   │   │   ├── messageRoutes.js
│   │   │   ├── notificationRoutes.js
│   │   │   └── patientRoutes.js
│   │   ├── .env
│   │   ├── package.json
│   │   ├── seed.js
│   │   └── server.js
│   │
│   └── frontend/
│       ├── src/
│       │   ├── components/
│       │   │   ├── NotificationBell.jsx
│       │   │   └── VoiceAssistant.jsx
│       │   ├── pages/
│       │   │   ├── Admin.jsx
│       │   │   ├── Appointments.jsx
│       │   │   ├── Dashboard.jsx
│       │   │   ├── DoctorMedications.jsx
│       │   │   ├── Documents.jsx
│       │   │   ├── EmergencySOS.jsx
│       │   │   ├── Health.jsx
│       │   │   ├── Insights.jsx
│       │   │   ├── Login.jsx
│       │   │   ├── MedicationReminders.jsx
│       │   │   ├── Medications.jsx
│       │   │   ├── Messages.jsx
│       │   │   ├── PatientDetail.jsx
│       │   │   └── Patients.jsx
│       │   ├── services/
│       │   │   ├── api.js
│       │   │   └── socket.js
│       │   ├── utils/
│       │   │   └── report.js
│       │   ├── App.jsx
│       │   ├── i18n.jsx
│       │   ├── main.jsx
│       │   └── styles.css
│       ├── index.html
│       ├── package.json
│       └── vite.config.js
```

### 2. Backend Package Installation
```bash
# Terminal Commands for Backend Installation
cd build/backend
npm install express mongoose bcryptjs jsonwebtoken cors dotenv socket.io multer
npm install -D nodemon
```

### 3. Database Connection
```javascript
// File: build/backend/server.js (Database Connection Section)
import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/patient_monitoring_system';

mongoose.connect(MONGO_URI)
  .then(() => console.log('MongoDB connection established successfully.'))
  .catch((err) => {
    console.error('MongoDB connection failure:', err.message);
    process.exit(1);
  });
```

### 4. Environment Variables
```env
# File: build/backend/.env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/patient_monitoring_system
JWT_SECRET=caretrack_clinical_jwt_secret_key_2026_super_secure
CLIENT_URL=http://localhost:5173
```

### 5. User Model
```javascript
// File: build/backend/models/User.js
import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['patient', 'doctor', 'admin'], default: 'patient' },
  specialization: { type: String, default: '' },
  phone: { type: String, default: '' },
  gender: { type: String, default: '' },
  bloodGroup: { type: String, default: '' },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

export default mongoose.model('User', userSchema);
```

### 6. Password Hashing and Registration
```javascript
// File: build/backend/routes/authRoutes.js (Registration Handler)
import { Router } from 'express';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';

const router = Router();

router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, specialization } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email and password are required' });
    }
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ message: 'Email already registered' });

    // Salt and hash password using bcryptjs
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const user = await User.create({
      name, email, password: hashedPassword,
      role: role === 'doctor' ? 'doctor' : 'patient',
      specialization: role === 'doctor' ? specialization : ''
    });

    res.status(201).json({ message: 'User registered successfully', userId: user._id });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
```

### 7. Login and JWT Generation
```javascript
// File: build/backend/routes/authRoutes.js (Login Handler)
import jwt from 'jsonwebtoken';

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ message: 'Invalid email or password' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ message: 'Invalid email or password' });
    if (user.isActive === false) return res.status(403).json({ message: 'Account deactivated' });

    // Generate JWT token valid for 7 days
    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET || 'caretrack_clinical_secret',
      { expiresIn: '7d' }
    );

    res.json({
      token,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        specialization: user.specialization
      }
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
```

### 8. Authentication Middleware
```javascript
// File: build/backend/middleware/auth.js
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

export async function protect(req, res, next) {
  let token = req.headers.authorization;
  if (token && token.startsWith('Bearer ')) {
    token = token.slice(7);
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password');
      if (!req.user) return res.status(401).json({ message: 'User not found' });
      return next();
    } catch (e) {
      return res.status(401).json({ message: 'Token invalid or expired' });
    }
  }
  return res.status(401).json({ message: 'Authorization required' });
}

export function roles(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Forbidden: Insufficient privileges' });
    }
    next();
  };
}
```

### 9. Create API (Doctor Prescribe Medication)
```javascript
// File: build/backend/routes/medicationRoutes.js (POST /send)
router.post('/send', protect, roles('doctor', 'admin'), async (req, res) => {
  try {
    const { patientId, name, dosage, time, frequency, instructions } = req.body;
    if (!patientId || !name) return res.status(400).json({ message: 'Patient and medication name required' });

    const med = await Medication.create({
      patient: patientId,
      name,
      dosage,
      time,
      frequency,
      instructions,
      active: true,
      source: 'doctor',
      prescribedBy: req.user._id
    });

    await Notification.create({
      user: patientId,
      title: 'New medication from your doctor',
      message: `Dr. ${req.user.name} prescribed ${name}${dosage ? ` (${dosage})` : ''}${time ? ` at ${time}` : ''}.`,
      type: 'medication'
    });

    const io = req.app.get('io');
    if (io) io.to(`user:${patientId}`).emit('notification:new', {
      title: 'New medication from your doctor',
      message: `Dr. ${req.user.name} prescribed ${name}`,
      type: 'medication'
    });

    res.status(201).json(med);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});
```

### 10. Read API (Role-Scoped Medications Fetch)
```javascript
// File: build/backend/routes/medicationRoutes.js (GET /)
router.get('/', protect, async (req, res) => {
  try {
    if (req.user.role === 'patient') {
      const list = await Medication.find({ patient: req.user._id })
        .populate('prescribedBy', 'name email specialization')
        .sort({ createdAt: -1 });
      return res.json(list);
    }
    if (req.user.role === 'doctor') {
      if (req.query.patientId) {
        const list = await Medication.find({ patient: req.query.patientId })
          .populate('prescribedBy', 'name email specialization')
          .populate('patient', 'name email phone')
          .sort({ createdAt: -1 });
        return res.json(list);
      }
      const list = await Medication.find({ prescribedBy: req.user._id })
        .populate('patient', 'name email phone gender')
        .populate('prescribedBy', 'name email specialization')
        .sort({ createdAt: -1 });
      return res.json(list);
    }
    res.json([]);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});
```

### 11. Update API (Patient Marking Medication as Taken)
```javascript
// File: build/backend/routes/medicationRoutes.js (PATCH /:id/take)
router.patch('/:id/take', protect, roles('patient'), async (req, res) => {
  try {
    const med = await Medication.findOne({ _id: req.params.id, patient: req.user._id });
    if (!med) return res.status(404).json({ message: 'Medication not found' });

    const now = new Date();
    med.lastTakenAt = now;
    if (!med.takenDates) med.takenDates = [];
    med.takenDates.push(now);
    await med.save();

    res.json({ message: 'Medication marked as taken', medication: med });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});
```

### 12. Delete API (Cancel Prescription)
```javascript
// File: build/backend/routes/medicationRoutes.js (DELETE /:id)
router.delete('/:id', protect, async (req, res) => {
  try {
    let med;
    if (req.user.role === 'patient') {
      med = await Medication.findOne({ _id: req.params.id, patient: req.user._id, source: 'patient' });
    } else if (req.user.role === 'doctor') {
      med = await Medication.findOne({ _id: req.params.id, prescribedBy: req.user._id });
    } else if (req.user.role === 'admin') {
      med = await Medication.findById(req.params.id);
    }

    if (!med) return res.status(404).json({ message: 'Medication not found or unauthorized' });

    await med.deleteOne();
    res.json({ message: 'Medication removed successfully' });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});
```

### 13. Express Routes Mounting
```javascript
// File: build/backend/server.js (Route Registration)
import authRoutes from './routes/authRoutes.js';
import healthRoutes from './routes/healthRoutes.js';
import appointmentRoutes from './routes/appointmentRoutes.js';
import patientRoutes from './routes/patientRoutes.js';
import dashboardRoutes from './routes/dashboardRoutes.js';
import medicationRoutes from './routes/medicationRoutes.js';
import notificationRoutes from './routes/notificationRoutes.js';
import messageRoutes from './routes/messageRoutes.js';
import documentRoutes from './routes/documentRoutes.js';
import emergencyRoutes from './routes/emergencyRoutes.js';
import insightsRoutes from './routes/insightsRoutes.js';

app.use('/api/auth', authRoutes);
app.use('/api/health', healthRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/patients', patientRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/medications', medicationRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/emergency', emergencyRoutes);
app.use('/api/insights', insightsRoutes);
```

### 14. Main Server File
```javascript
// File: build/backend/server.js
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { verifyToken } from './middleware/auth.js';

dotenv.config();
const app = express();
const httpServer = createServer(app);

const io = new Server(httpServer, {
  cors: { origin: ['http://localhost:5173', 'http://localhost:5174'] }
});

app.use(cors());
app.use(express.json());
app.set('io', io);

io.use(async (socket, next) => {
  try {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('Authentication required'));
    socket.user = await verifyToken(token);
    next();
  } catch (e) {
    next(new Error('Invalid token'));
  }
});

io.on('connection', (socket) => {
  socket.join(`user:${socket.user._id}`);
});

const PORT = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI)
  .then(() => httpServer.listen(PORT, () => console.log(`Server running on port ${PORT}`)));
```

### 15. React Login Component
```javascript
// File: build/frontend/src/pages/Login.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useLanguage } from '../i18n';
import VoiceAssistant from '../components/VoiceAssistant';

export default function Login({ onLoginSuccess }) {
  const { t } = useLanguage();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { data } = await api.post('/auth/login', form);
      localStorage.setItem('token', data.token);
      localStorage.setItem('role', data.user.role);
      localStorage.setItem('user', JSON.stringify(data.user));
      window.dispatchEvent(new Event('caretrack:auth-change'));
      if (onLoginSuccess) onLoginSuccess();
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <form className="card login-card" onSubmit={submit}>
        <h1>❤ CareTrack</h1>
        <p className="muted">{t('subtitle')}</p>
        <input type="email" placeholder={t('email')} required
          value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
        <input type="password" placeholder={t('password')} required
          value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
        {error && <div className="error">{error}</div>}
        <button className="primary" type="submit" disabled={loading}>
          {loading ? 'Please wait…' : t('login')}
        </button>
      </form>
      <VoiceAssistant />
    </div>
  );
}
```

### 16. Admin Dashboard Logic
```javascript
// File: build/backend/routes/adminRoutes.js (Overview Stats)
import { Router } from 'express';
import User from '../models/User.js';
import HealthRecord from '../models/HealthRecord.js';
import Appointment from '../models/Appointment.js';
import { protect, roles } from '../middleware/auth.js';

const router = Router();

router.get('/overview', protect, roles('admin'), async (req, res) => {
  try {
    const totalPatients = await User.countDocuments({ role: 'patient' });
    const totalDoctors = await User.countDocuments({ role: 'doctor' });
    const activeAlerts = await HealthRecord.countDocuments({ status: 'alert' });
    const pendingAppointments = await Appointment.countDocuments({ status: 'pending' });

    res.json({
      totalPatients,
      totalDoctors,
      activeAlerts,
      pendingAppointments
    });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

export default router;
```

### 17. REST API Request and Response Examples

#### Example 1: Doctor Prescribe Medication
**HTTP Request:**
```http
POST /api/medications/send HTTP/1.1
Host: localhost:5000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json

{
  "patientId": "6aa6acd542d775c6bbaee0fa",
  "name": "Metformin",
  "dosage": "500 mg",
  "time": "08:00",
  "frequency": "Twice daily",
  "instructions": "Take after meals with warm water"
}
```

**HTTP Response:**
```json
{
  "_id": "670830fa982a56e01c7782a1",
  "patient": "6aa6acd542d775c6bbaee0fa",
  "name": "Metformin",
  "dosage": "500 mg",
  "time": "08:00",
  "frequency": "Twice daily",
  "instructions": "Take after meals with warm water",
  "active": true,
  "source": "doctor",
  "prescribedBy": "6aa6acd542d775c6bbaee0f9",
  "createdAt": "2026-10-10T14:30:18.412Z",
  "updatedAt": "2026-10-10T14:30:18.412Z"
}
```

#### Example 2: Patient Record Dose Taken
**HTTP Request:**
```http
PATCH /api/medications/670830fa982a56e01c7782a1/take HTTP/1.1
Host: localhost:5000
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
```

**HTTP Response:**
```json
{
  "message": "Medication marked as taken",
  "medication": {
    "_id": "670830fa982a56e01c7782a1",
    "name": "Metformin",
    "active": true,
    "lastTakenAt": "2026-10-10T14:35:00.120Z",
    "takenDates": [
      "2026-10-10T14:35:00.120Z"
    ]
  }
}
```

---

<div style="page-break-after: always;"></div>

# SCREENSHOTS OF THE PROJECT

### 1. Clean Authentication Screen (`/login`)
- Clean user-friendly interface displaying the CareTrack branding and language selector.
- Fields for Email and Password with validation indicators.
- Seamless toggle for Patient / Doctor self-registration.
- Fixed layout with all demo artifacts removed.

### 2. Doctor Prescriptions & Medications Management Screen (`/medications` - Doctor Role)
- Dynamic patient picker dropdown allowing the physician to select any registered patient.
- Form controls for Medicine Name, Dosage, Reminder Time, Frequency, and Instructions.
- Voice dictation banner with example syntax in the active language.
- Active prescriptions data grid displaying Patient Name, Medicine, Timing, Status, and Pause/Cancel controls.

### 3. Patient Medication Reminders & Schedule Screen (`/medications` - Patient Role)
- **Today's Medication Schedule Cards:** Organized cards displaying scheduled doses with reminder badges (*"⏰ 08:00 AM"*), medicine name (*"Metformin 500mg"*), and prescribing doctor info (*"👨‍⚕️ Dr. Asha Rao"*).
- **"✔ Mark as Taken" Button:** Instantly switches to a green confirmed state (*"✅ Taken today at 08:35 AM"*).
- Optional accordion form allowing patients to register OTC personal reminders.

### 4. Multilingual Voice Assistant Overlay (Universal across all screens)
- Floating microphone FAB button with pulsing radial wave animation during speech capture.
- Live interim speech transcript card displaying captured phonemes.
- Quick suggestion chips in regional languages (*"டாஷ்போர்டு"*, *"மருந்துகள்"*, *"சந்திப்புகள்"*).
- Auditory feedback generated by `window.speechSynthesis`.

### 5. Health Vitals Trend & AI Risk Center (`/health`, `/insights`)
- Recharts graphical line charts displaying 14-day systolic/diastolic BP, SpO₂, and heart rate trends.
- Algorithmic 7-day monitoring banner highlighting categorized risk status (*🟢 Stable*, *🟡 Attention*, *🔴 Critical*).
- Anomaly flags triggered whenever patient vitals exceed clinically safe bounds.

---

<div style="page-break-after: always;"></div>

# REFERENCES

1. World Health Organization (WHO), "Digital Health: Global Strategy on Digital Health 2020–2025," *WHO Guidelines*, Geneva, Switzerland, 2021.
2. J. Smith, R. Davis, and M. Johnson, "Impact of Continuous Remote Patient Monitoring on Chronic Disease Management: A Systematic Review," *IEEE Journal of Biomedical and Health Informatics*, vol. 25, no. 6, pp. 2102–2111, June 2021.
3. K. V. Rao and S. Sundaram, "Addressing Linguistic and Accessibility Barriers in Healthcare Telematics across South Asia," *ACM Transactions on Accessible Computing*, vol. 15, no. 2, pp. 88–104, May 2022.
4. P. Gupta, A. Kumar, and S. Patel, "Client-Side Speech Recognition Using the Web Speech API for Low-Bandwidth Medical Form Entry," *Proceedings of the IEEE International Conference on Healthcare Informatics (ICHI)*, pp. 340–348, June 2023.
5. S. C. Mukhopadhyay, "Wearable and Remote Telehealth Technologies: Review and Future Directions," *IEEE Sensors Journal*, vol. 22, no. 4, pp. 2933–2946, Feb. 2022.
6. Mozilla Developer Network (MDN), "Web Speech API Specification and Browser Interoperability," *W3C Community Group Report*, 2024. [Online]. Available: https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API
7. React Documentation, "Building Robust Single Page Applications with React 18," *React Foundation*, 2023. [Online]. Available: https://react.dev
8. MongoDB Inc., "Mongoose v8 ODM Documentation: Schema Validation and Relational Population," 2024. [Online]. Available: https://mongoosejs.com
