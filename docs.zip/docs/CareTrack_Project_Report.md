# CareTrack: Intelligent Patient Monitoring, Multilingual Voice Assistant & Clinical Telehealth System

---

## Academic Project Documentation & Technical Report

**Project Title:** CareTrack: Intelligent Remote Patient Monitoring with Multilingual Voice Assistant and Clinical Telehealth  
**Domain:** Healthcare Informatics / Web Engineering / Distributed Full-Stack Systems  
**Architecture:** MERN Stack (MongoDB, Express.js, React.js, Node.js) with Web Speech API and Socket.IO  

---

## Table of Contents
1. [Executive Summary / Abstract](#1-executive-summary--abstract)
2. [Introduction & Background](#2-introduction--background)
3. [Problem Statement & Existing System Limitations](#3-problem-statement--existing-system-limitations)
4. [Proposed System & Core Objectives](#4-proposed-system--core-objectives)
5. [System Architecture](#5-system-architecture)
6. [Technology Stack](#6-technology-stack)
7. [Detailed Module Breakdown](#7-detailed-module-breakdown)
   - [7.1 Role-Based Authentication & Security](#71-role-based-authentication--security)
   - [7.2 Doctor Medication Prescription Module](#72-doctor-medication-prescription-module)
   - [7.3 Patient Medication Reminders & Dose Tracking](#73-patient-medication-reminders--dose-tracking)
   - [7.4 Universal Multilingual Voice Assistant](#74-universal-multilingual-voice-assistant)
   - [7.5 Health Vitals Tracking & Explainable 7-Day AI Risk Assessment](#75-health-vitals-tracking--explainable-7-day-ai-risk-assessment)
   - [7.6 Emergency SOS with GPS Geolocation Tracking](#76-emergency-sos-with-gps-geolocation-tracking)
   - [7.7 Real-Time Messaging & Notifications](#77-real-time-messaging--notifications)
   - [7.8 Clinical Document Management & PDF Report Generation](#78-clinical-document-management--pdf-report-generation)
8. [Database Schema Design & ER Diagram](#8-database-schema-design--er-diagram)
9. [REST API Specifications](#9-rest-api-specifications)
10. [Workflows & Sequence Diagrams](#10-workflows--sequence-diagrams)
11. [Testing & Validation](#11-testing--validation)
12. [Conclusion & Future Enhancements](#12-conclusion--future-enhancements)

---

## 1. Executive Summary / Abstract

In contemporary healthcare, remote patient monitoring (RPM) and telehealth play an essential role in chronic disease management, post-operative care, and elderly patient assistance. However, conventional digital health platforms suffer from two critical shortcomings: **complex user interfaces that exclude elderly or low-literacy patients**, and **the absence of regional language support**.

**CareTrack** is a full-stack clinical telehealth and patient monitoring web system designed to bridge this accessibility gap. Built upon the MERN (MongoDB, Express, React, Node.js) ecosystem, CareTrack incorporates:
- **Separated Clinical Workflows:** A dedicated doctor prescription portal paired with a patient medication adherence tracker with scheduled dosage alarms and one-click *"Mark as Taken"* confirmations.
- **Universal Multilingual Voice Assistant:** Driven by the browser Web Speech API, enabling voice-driven hands-free navigation and form auto-filling across **English, Tamil (தமிழ் & Tanglish), Hindi (हिन्दी), Telugu (తెలుగు), and Malayalam (മലയാളം)** with bidirectional text-to-speech feedback.
- **Explainable 7-Day Health Trend & Risk Engine:** Algorithmic vitals evaluation (Blood Pressure, Blood Sugar, SpO₂, Heart Rate, Body Temperature) detecting abnormal trends without reliance on opaque external black-box APIs.
- **Emergency SOS & Live Geolocation:** One-touch alert broadcasting the patient's real-time GPS coordinates directly to doctors through WebSocket event streaming.

---

## 2. Introduction & Background

The global rise of chronic conditions such as hypertension, diabetes, and cardiovascular diseases requires continuous vital monitoring rather than sporadic clinic consultations. Traditional patient management is constrained by physical hospital queues, delayed clinical interventions, and low medication compliance.

Moreover, in linguistically diverse nations like India, English-only interfaces create an adoption barrier for rural and non-native English speakers. CareTrack integrates **voice-driven interaction in vernacular languages** directly into a responsive clinical dashboard, allowing patients to dictate their health metrics (*"BP 120/80, Sugar 110"*) and navigate screens hands-free.

---

## 3. Problem Statement & Existing System Limitations

### Existing System Drawbacks:
1. **Linguistic Exclusion:** Most telehealth applications support only English, preventing elderly and rural demographics from interacting effectively.
2. **Fragmented Medication Management:** Existing apps treat medication reminders as isolated smartphone alarms disconnected from actual prescribing physicians.
3. **Complex Manual Input:** Patients suffering from motor tremors, visual impairment, or illness struggle with small on-screen text fields and dropdowns.
4. **Lack of Instant Emergency Triage:** Medical alert systems often rely on manual phone calls rather than instant telemetry accompanied by GPS coordinates.
5. **High Cloud AI Dependency:** Many commercial apps send sensitive personal vitals to third-party commercial LLM providers, raising severe patient data privacy concerns.

### Comparative Feature Analysis:

| Feature Dimension | Traditional Hospital Portals | Standard Health Apps | **CareTrack (Proposed)** |
|---|---|---|---|
| **Language Support** | English Only | English + Hindi | 5 Indian Languages (English, Tamil, Hindi, Telugu, Malayalam) |
| **Input Modality** | Keyboard / Mouse Only | Manual Touch | Voice Typing + Manual + Hands-Free Navigation |
| **Doctor-Patient Prescription Link** | Paper Prescriptions / Static PDFs | Self-added Reminders Only | Direct Doctor Digital Prescription $\rightarrow$ Patient Reminder Synchronization |
| **Medication Adherence Tracking** | None | Notification dismissal | One-Click *"Mark as Taken"* with Timestamps & Adherence History |
| **Risk Prediction** | Doctor Manual Review | Cloud AI (Data Privacy Risk) | Local Explainable Algorithmic 7-Day Trend Analyzer |
| **Emergency SOS** | Emergency Helpline Call | Simple Alert | Live Browser GPS Geolocation Link via WebSockets |
| **Doctor Communication** | Appointment booking only | Static Email / SMS | Real-time Socket.IO In-App Chat & Notifications |

---

## 4. Proposed System & Core Objectives

CareTrack addresses these challenges through the following objectives:
- **Centralized Doctor Prescribing Portal:** Allow licensed physicians to search assigned patients, prescribe medicines with specific dosages, frequencies, and administration guidelines (*"After meals"*).
- **Patient Schedule Alarms:** Convert doctor prescriptions directly into daily dose cards sorted by schedule (Morning, Afternoon, Evening, Night) with adherence confirmation.
- **Zero-Friction Voice Control:** Provide native Web Speech API recognition that responds to Tamil voice instructions (*"மருந்துகள்"*, *"டாஷ்போர்டு"*, *"பாராசிட்டமால் எடுத்துக்கொண்டேன்"*).
- **Privacy-Preserving Edge Analytics:** Execute clinical trend detection algorithms locally on the secure backend, providing explainable risk summaries without third-party data leakage.

---

## 5. System Architecture

CareTrack follows a multi-tier client-server architecture with an asynchronous real-time event pipeline:

```mermaid
graph TD
    subgraph Client_Layer ["Client Layer (React 18 + Vite)"]
        UI["Web UI Components"]
        VA["Voice Assistant (Web Speech API)"]
        i18n["Reactive Multilingual Provider"]
        WSClient["Socket.IO Client"]
    end

    subgraph Transport_Layer ["Transport & API Layer"]
        REST["REST API (HTTP/JSON + JWT)"]
        WSS["WebSocket Server (Socket.IO Rooms)"]
    end

    subgraph Service_Layer ["Backend Layer (Node.js + Express)"]
        AuthM["Auth & RBAC Middleware"]
        MedS["Medication & Prescription Service"]
        HealthS["Health Vitals & Risk Engine"]
        EmergS["Emergency Geolocation Service"]
        MsgS["Real-time Chat & Notifications"]
    end

    subgraph Persistence_Layer ["Data Persistence (MongoDB)"]
        DB[("MongoDB Community / Atlas Database")]
        Uploads[("Secure Clinical Document Storage")]
    end

    UI --> REST
    VA --> UI
    i18n --> UI
    WSClient <--> WSS

    REST --> AuthM
    AuthM --> MedS
    AuthM --> HealthS
    AuthM --> EmergS
    AuthM --> MsgS

    WSS <--> MsgS
    WSS <--> EmergS

    MedS --> DB
    HealthS --> DB
    EmergS --> DB
    MsgS --> DB
    REST --> Uploads
```

---

## 6. Technology Stack

### Frontend Architecture
- **Framework:** React 18 (SPA) with Vite Build Tooling
- **Navigation:** React Router DOM v6 with Dynamic Role Guards
- **Data Visualization:** Recharts for Vitals Trend Analysis
- **Voice Engine:** Browser Native Web Speech API (`SpeechRecognition` & `SpeechSynthesis`)
- **HTTP Client:** Axios with Request/Response Interceptors for Bearer JWT Authorization
- **Styling:** Modular Responsive CSS with Flexible Grid Layouts

### Backend Architecture
- **Runtime:** Node.js (ES Modules syntax)
- **Web Framework:** Express.js 4.x
- **Real-Time Communication:** Socket.IO 4.x (User-specific room routing)
- **Authentication:** JSON Web Tokens (JWT) with bcryptjs (10 salt rounds)
- **File Handling:** Multer for Multipart Medical Document uploads

### Database Architecture
- **Database Engine:** MongoDB (Document-Oriented NoSQL)
- **Object Modeling:** Mongoose ODM 8.x with Strict Schemas and Timestamping

---

## 7. Detailed Module Breakdown

### 7.1 Role-Based Authentication & Security
- **Triple-Role Ecosystem:** Patients, Doctors, and System Administrators.
- **Secure Token Flow:** Passwords hashed with bcrypt; authorization enforced via `Authorization: Bearer <token>` middleware.
- **Dynamic Session Synchronization:** Client-side React state listens for `caretrack:auth-change` events, ensuring smooth transitions without stale route caches.
- **Clean Access:** Production authentication form with email and password verification.

### 7.2 Doctor Medication Prescription Module (`DoctorMedications.jsx`)
- **Patient Selector:** Allows doctors to filter and prescribe to registered patients.
- **Structured Clinical Fields:**
  - Medication Name
  - Dosage (e.g., `500 mg`, `1 tablet`)
  - Reminder Timing (e.g., `08:00 AM`, `20:00`)
  - Frequency (e.g., `Twice daily`, `Once at bedtime`)
  - Administration Instructions (e.g., `After meals with warm water`)
- **Real-time Push Dispatch:** Generates a database notification and transmits a WebSocket alert (`notification:new`) directly to the target patient.
- **Prescription Control:** Allows doctors to Pause, Resume, or Cancel prescriptions.

### 7.3 Patient Medication Reminders & Dose Tracking (`MedicationReminders.jsx`)
- **Visual Schedule Cards:** Highlights doses for the current day categorized by schedule timing.
- **One-Click Adherence Confirmation:** Patients click *"✔ Mark as Taken"* to record dosage completion (`PATCH /api/medications/:id/take`).
- **Audit History:** Stores array of `takenDates` timestamps to verify medication adherence over time.
- **Personal OTC Section:** Patients can add supplementary vitamins or eye drops without altering doctor prescriptions.

### 7.4 Universal Multilingual Voice Assistant (`VoiceAssistant.jsx`)
- **Continuous Voice Navigation:** Users can speak natural phrases or simply single words to jump to screens:
  - English: *"Medications"*, *"Health records"*, *"Dashboard"*, *"Emergency"*
  - Tamil Script: *"மருந்துகள்"*, *"உடல்நல பதிவுகள்"*, *"டாஷ்போர்டு"*, *"அவசரம்"*
  - Tanglish: *"marunthu ku po"*, *"health records kaattu"*, *"dashboard poga"*
- **Form Auto-Filling:** Parses complex spoken medical strings into structured values:
  - *"patient Demo Patient, medicine Paracetamol, dosage 500 mg, frequency twice a day, time 8 pm, instructions after food"*
  - *"BP 120 80, sugar 110, pulse 72, oxygen 98, temp 98.6"*
- **Voice Dose Confirmation:** Patient can speak *"paracetamol எடுத்துக்கொண்டேன்"* to automatically log the dose as taken.
- **Spoken Text-to-Speech:** Responds with auditory confirmation in the active language via `window.speechSynthesis`.

### 7.5 Health Vitals Tracking & Explainable 7-Day AI Risk Assessment
- **Vitals Collected:** Systolic/Diastolic BP (mmHg), Blood Glucose (mg/dL), SpO₂ (%), Heart Rate (BPM), Body Temperature (°F), and Body Weight (kg).
- **Rule-Based Trend Analytics:** Compares recent 7-day readings against clinical thresholds:
  - High Blood Pressure ($>140/90\text{ mmHg}$) $\rightarrow$ Alert trigger
  - Hypoxemia ($\text{SpO}_2 < 95\%$) $\rightarrow$ Urgent clinical notification
  - Dysglycemia ($\text{Blood Sugar} > 180\text{ mg/dL}$) $\rightarrow$ Warning flag
- **Wellness Score:** Algorithmic calculation of a wellness score (0–100) displaying trend stability without sending data off-device.

### 7.6 Emergency SOS with GPS Geolocation Tracking (`EmergencySOS.jsx`)
- **One-Touch Trigger:** Initiates emergency protocol with GPS coordinates via browser `navigator.geolocation`.
- **Dynamic Google Maps Link:** Automatically generates an emergency URL (`https://maps.google.com/?q=lat,lng`) and notifies the attending doctor.

### 7.7 Real-Time Messaging & Notifications
- **Socket.IO Teleconsultation:** Low-latency doctor-patient messaging.
- **Persistent Notifications:** Notification bell with unread counters and live push popups.

### 7.8 Clinical Document Management & PDF Report Generation
- **Document Repository:** Supports upload of pathology reports, ECGs, and imaging documents (PDF, JPG, PNG).
- **Clinical Summary PDF Generator:** Doctor can compile vitals, Recharts trend graphs, doctor notes, and active medications into a printable PDF report.

---

## 8. Database Schema Design & ER Diagram

```mermaid
erDiagram
    USER ||--o{ HEALTH_RECORD : logs
    USER ||--o{ APPOINTMENT : books_or_conducts
    USER ||--o{ MEDICATION : prescribed_or_taken
    USER ||--o{ NOTIFICATION : receives
    USER ||--o{ MESSAGE : sends_or_receives
    USER ||--o{ MEDICAL_DOCUMENT : uploads
    USER ||--o{ EMERGENCY_ALERT : triggers

    USER {
        ObjectId _id PK
        string name
        string email UK
        string password
        string role "patient | doctor | admin"
        string specialization
        string phone
        string gender
        string bloodGroup
        boolean isActive
    }

    HEALTH_RECORD {
        ObjectId _id PK
        ObjectId patient FK
        number heartRate
        number systolic
        number diastolic
        number spo2
        number temperature
        number bloodSugar
        number weight
        string status "normal | alert"
        Date recordedAt
    }

    MEDICATION {
        ObjectId _id PK
        ObjectId patient FK
        ObjectId prescribedBy FK
        string name
        string dosage
        string time
        string frequency
        string instructions
        boolean active
        string source "patient | doctor"
        Date lastTakenAt
        Array takenDates
    }

    APPOINTMENT {
        ObjectId _id PK
        ObjectId patient FK
        ObjectId doctor FK
        Date date
        string reason
        string status "pending | confirmed | completed | cancelled"
    }

    NOTIFICATION {
        ObjectId _id PK
        ObjectId user FK
        string title
        string message
        string type "health | appointment | message | medication | emergency"
        boolean read
    }

    EMERGENCY_ALERT {
        ObjectId _id PK
        ObjectId patient FK
        number latitude
        number longitude
        string status "active | resolved"
        Date triggeredAt
    }
```

---

## 9. REST API Specifications

| Method | Endpoint | Access Role | Description |
|---|---|---|---|
| `POST` | `/api/auth/register` | Public | Register new patient or doctor account |
| `POST` | `/api/auth/login` | Public | Authenticate user credentials and return JWT |
| `GET` | `/api/patients` | Doctor, Admin | Retrieve list of registered patients |
| `GET` | `/api/patients/doctors` | Patient | Retrieve list of verified doctors |
| `GET` | `/api/medications` | Patient, Doctor | Fetch role-scoped medications (with doctor info) |
| `POST` | `/api/medications/send` | Doctor, Admin | Prescribe medication to patient with live alert |
| `PATCH` | `/api/medications/:id/take` | Patient | Record medication intake timestamp |
| `PUT` | `/api/medications/:id` | Patient, Doctor | Toggle active status or edit prescription |
| `DELETE` | `/api/medications/:id` | Patient, Doctor | Remove or cancel prescription |
| `GET` | `/api/health` | Patient | Retrieve patient vitals history |
| `POST` | `/api/health` | Patient | Submit new vitals readings with anomaly check |
| `GET` | `/api/insights/patient/:id` | Doctor, Admin | Retrieve 7-day algorithmic risk metrics |
| `POST` | `/api/emergency/sos` | Patient | Trigger SOS event with GPS latitude/longitude |
| `GET` | `/api/appointments` | All Roles | Fetch user-specific scheduled appointments |
| `POST` | `/api/appointments` | Patient | Book consultation appointment with chosen doctor |
| `GET` | `/api/messages/:userId` | All Roles | Fetch chat conversation history |
| `POST` | `/api/messages` | All Roles | Send real-time chat message |
| `POST` | `/api/documents` | Patient | Upload medical document / report file |

---

## 10. Workflows & Sequence Diagrams

### Doctor Prescribing to Patient with Live Alert:

```mermaid
sequenceDiagram
    autonumber
    actor Doctor
    participant DocPage as DoctorMedications UI
    participant Backend as Express API Server
    participant DB as MongoDB
    participant Socket as Socket.IO Hub
    actor Patient
    participant PatPage as MedicationReminders UI

    Doctor->>DocPage: Fills / Speaks Prescription (Paracetamol 500mg, 8am)
    DocPage->>Backend: POST /api/medications/send {patientId, name, dosage, time...}
    Backend->>DB: Save Medication (source: 'doctor', prescribedBy: doctorId)
    Backend->>DB: Create Notification (type: 'medication')
    Backend->>Socket: io.to("user:" + patientId).emit("notification:new")
    Socket-->>PatPage: Push Live Notification Alert
    Backend-->>DocPage: 201 Created (Medication Record)
    PatPage-->>Patient: Displays Prescription Card with "Mark as Taken" Button
```

### Patient Taking Medication Workflow:

```mermaid
sequenceDiagram
    autonumber
    actor Patient
    participant UI as MedicationReminders UI
    participant API as Express API Server
    participant DB as MongoDB

    Patient->>UI: Clicks "Mark as Taken" OR Speaks "Paracetamol எடுத்தாச்சு"
    UI->>API: PATCH /api/medications/:id/take
    API->>DB: Update lastTakenAt = new Date(), push to takenDates
    DB-->>API: Updated Record Confirmed
    API-->>UI: 200 OK Response
    UI->>Patient: Changes Badge to "✅ Taken today at 08:30 AM" + Spoken Audio Feedback
```

---

## 11. Testing & Validation

### 1. Functional Testing:
- **Authentication:** Verified JWT issuance, role-based page protection, and instant dashboard redirect on login.
- **Medication Separation:** Verified doctor is presented with patient prescribing tools, while patient sees scheduled dosage cards and *"Mark as Taken"* actions.
- **Voice Parser Accuracy:** Validated against English, Tamil script, and Tanglish phrases. All major navigation keywords (`மருந்துகள்`, `டாஷ்போர்டு`, `சந்திப்புகள்`) correctly route within $<300\text{ ms}$.
- **WebSocket Streaming:** Verified real-time delivery of notifications and doctor-patient chat without manual page reloads.

### 2. Cross-Browser & Security Compliance:
- **Speech Recognition:** Verified on Chromium engines (Google Chrome, Microsoft Edge) supporting Web Speech API.
- **Security:** Sanitized input handling, CORS origin isolation, and JWT Bearer validation across protected API endpoints.

---

## 12. Conclusion & Future Enhancements

### Conclusion:
**CareTrack** successfully delivers an inclusive, accessible remote patient monitoring system. By decoupling doctor prescription workflows from patient adherence reminders and uniting them with an intuitive **multilingual voice assistant**, the application removes digital literacy and language barriers in healthcare management. The system operates with zero external AI operational costs by utilizing lightweight client-side speech recognition and server-side rule-based risk classification.

### Future Scope & Roadmap:
1. **IoT Bluetooth Medical Device Sync:** Direct BLE pairing with digital BP cuffs, pulse oximeters, and glucometers.
2. **Telephony & SMS Fallback:** Integration with Twilio/WhatsApp Business APIs to deliver SMS reminders for patients without smartphones.
3. **Offline Progressive Web App (PWA):** Service workers with IndexedDB caching allowing medication reminders to trigger even when offline.
4. **Clinical Decision Support System (CDSS):** Integration of FHIR (Fast Healthcare Interoperability Resources) data models for hospital electronic health record (EHR) interoperability.

---

*Report generated for CareTrack Healthcare Informatics System · Version 2.0*
